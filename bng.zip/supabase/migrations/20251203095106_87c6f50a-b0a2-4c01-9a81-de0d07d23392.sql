-- Create app_role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

-- Create user_roles table for role management
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL DEFAULT 'user',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function for role checking
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- RLS policies for user_roles
CREATE POLICY "Users can view their own roles"
ON public.user_roles
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
ON public.user_roles
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage roles"
ON public.user_roles
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create site_config table for site settings
CREATE TABLE public.site_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key TEXT NOT NULL UNIQUE,
    value TEXT,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_by UUID REFERENCES auth.users(id)
);

-- Enable RLS on site_config
ALTER TABLE public.site_config ENABLE ROW LEVEL SECURITY;

-- Everyone can read site config
CREATE POLICY "Anyone can read site config"
ON public.site_config
FOR SELECT
TO authenticated, anon
USING (true);

-- Only admins can modify site config
CREATE POLICY "Admins can modify site config"
ON public.site_config
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create bungalows table
CREATE TABLE public.bungalows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    description TEXT,
    short_description TEXT,
    capacity INTEGER NOT NULL DEFAULT 2,
    bedrooms INTEGER NOT NULL DEFAULT 1,
    bathrooms INTEGER NOT NULL DEFAULT 1,
    size INTEGER NOT NULL DEFAULT 50,
    price_per_night DECIMAL(10,2) NOT NULL DEFAULT 0,
    images TEXT[] DEFAULT '{}',
    features TEXT[] DEFAULT '{}',
    amenities TEXT[] DEFAULT '{}',
    view TEXT DEFAULT 'orman',
    has_jacuzzi BOOLEAN DEFAULT false,
    has_fireplace BOOLEAN DEFAULT false,
    has_private_pool BOOLEAN DEFAULT false,
    is_popular BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    rating DECIMAL(3,2) DEFAULT 5.0,
    review_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on bungalows
ALTER TABLE public.bungalows ENABLE ROW LEVEL SECURITY;

-- Everyone can read active bungalows
CREATE POLICY "Anyone can read active bungalows"
ON public.bungalows
FOR SELECT
TO authenticated, anon
USING (is_active = true);

-- Admins can read all bungalows
CREATE POLICY "Admins can read all bungalows"
ON public.bungalows
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- Admins can manage bungalows
CREATE POLICY "Admins can manage bungalows"
ON public.bungalows
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create gallery_images table
CREATE TABLE public.gallery_images (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    url TEXT NOT NULL,
    title TEXT,
    category TEXT DEFAULT 'bungalov',
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on gallery_images
ALTER TABLE public.gallery_images ENABLE ROW LEVEL SECURITY;

-- Everyone can read active gallery images
CREATE POLICY "Anyone can read active gallery images"
ON public.gallery_images
FOR SELECT
TO authenticated, anon
USING (is_active = true);

-- Admins can manage gallery images
CREATE POLICY "Admins can manage gallery images"
ON public.gallery_images
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create faqs table
CREATE TABLE public.faqs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on faqs
ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;

-- Everyone can read active faqs
CREATE POLICY "Anyone can read active faqs"
ON public.faqs
FOR SELECT
TO authenticated, anon
USING (is_active = true);

-- Admins can manage faqs
CREATE POLICY "Admins can manage faqs"
ON public.faqs
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
CREATE TRIGGER update_bungalows_updated_at
    BEFORE UPDATE ON public.bungalows
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_faqs_updated_at
    BEFORE UPDATE ON public.faqs
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_site_config_updated_at
    BEFORE UPDATE ON public.site_config
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default site config values
INSERT INTO public.site_config (key, value) VALUES
    ('site_name', 'Zen Bungalov'),
    ('site_tagline', 'Doğanın Kalbinde Lüks Konaklama'),
    ('site_description', 'Türkiye''nin en güzel doğal güzelliklerinde, modern konfor ve doğanın buluştuğu premium bungalov deneyimi.'),
    ('phone', '+90 532 123 45 67'),
    ('whatsapp', '905321234567'),
    ('email', 'info@zenbungalov.com'),
    ('address', 'Sapanca Gölü Mevkii, No: 42, Sapanca / Sakarya'),
    ('working_hours', '09:00 - 22:00'),
    ('instagram', 'https://instagram.com/dogabungalov'),
    ('facebook', 'https://facebook.com/dogabungalov'),
    ('twitter', 'https://twitter.com/dogabungalov'),
    ('google_maps_url', 'https://maps.google.com/?q=40.6892,29.8867'),
    ('coordinates_lat', '40.6892'),
    ('coordinates_lng', '29.8867'),
    ('logo_url', '');