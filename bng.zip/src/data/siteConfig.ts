export const siteConfig = {
  name: 'Zen Bungalov',
  tagline: 'Doğanın Kalbinde Lüks Konaklama',
  description: 'Türkiye\'nin en güzel doğal güzelliklerinde, modern konfor ve doğanın buluştuğu premium bungalov deneyimi.',
  phone: '+90 532 123 45 67',
  whatsapp: '905321234567',
  email: 'info@dogabungalov.com',
  address: 'Sapanca Gölü Mevkii, No: 42, Sapanca / Sakarya',
  workingHours: '09:00 - 22:00',
  socialMedia: {
    instagram: 'https://instagram.com/dogabungalov',
    facebook: 'https://facebook.com/dogabungalov',
    twitter: 'https://twitter.com/dogabungalov',
  },
  googleMapsUrl: 'https://maps.google.com/?q=40.6892,29.8867',
  coordinates: {
    lat: 40.6892,
    lng: 29.8867,
  },
};

export const generateWhatsAppLink = (message: string): string => {
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${siteConfig.whatsapp}?text=${encodedMessage}`;
};

export const generateReservationMessage = (
  bungalowName: string,
  checkIn: string,
  checkOut: string,
  guests: number
): string => {
  return `Merhaba, rezervasyon yapmak istiyorum:

Bungalov: ${bungalowName}
Giriş: ${checkIn}
Çıkış: ${checkOut}
Kişi: ${guests}

Ad Soyad:
Telefon:`;
};
