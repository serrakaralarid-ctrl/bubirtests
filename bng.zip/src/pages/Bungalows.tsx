import { useState, useMemo } from 'react';
import { Layout } from '@/components/layout/Layout';
import { SectionHeader } from '@/components/common/SectionHeader';
import { BungalowCard } from '@/components/bungalow/BungalowCard';
import { useBungalows, Bungalow } from '@/hooks/useBungalows';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Filter, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { Skeleton } from '@/components/ui/skeleton';

const viewOptions = [
  { value: 'all', label: 'Tüm Manzaralar' },
  { value: 'orman', label: 'Orman' },
  { value: 'göl', label: 'Göl' },
  { value: 'dağ', label: 'Dağ' },
  { value: 'deniz', label: 'Deniz' },
];

const capacityOptions = [
  { value: '0', label: 'Tüm Kapasiteler' },
  { value: '2', label: '2+ Kişi' },
  { value: '4', label: '4+ Kişi' },
  { value: '6', label: '6+ Kişi' },
];

const Bungalows = () => {
  const { data: bungalows, isLoading } = useBungalows();
  const [showFilters, setShowFilters] = useState(false);
  const [viewFilter, setViewFilter] = useState('all');
  const [capacityFilter, setCapacityFilter] = useState('0');
  const [priceRange, setPriceRange] = useState([0, 10000]);
  const [hasJacuzzi, setHasJacuzzi] = useState(false);
  const [hasFireplace, setHasFireplace] = useState(false);
  const [hasPool, setHasPool] = useState(false);

  const filteredBungalows = useMemo(() => {
    if (!bungalows) return [];
    return bungalows.filter((b: Bungalow) => {
      if (viewFilter !== 'all' && b.view !== viewFilter) return false;
      if (parseInt(capacityFilter) > 0 && b.capacity < parseInt(capacityFilter)) return false;
      if (Number(b.price_per_night) < priceRange[0] || Number(b.price_per_night) > priceRange[1]) return false;
      if (hasJacuzzi && !b.has_jacuzzi) return false;
      if (hasFireplace && !b.has_fireplace) return false;
      if (hasPool && !b.has_private_pool) return false;
      return true;
    });
  }, [bungalows, viewFilter, capacityFilter, priceRange, hasJacuzzi, hasFireplace, hasPool]);

  const resetFilters = () => {
    setViewFilter('all');
    setCapacityFilter('0');
    setPriceRange([0, 10000]);
    setHasJacuzzi(false);
    setHasFireplace(false);
    setHasPool(false);
  };

  const hasActiveFilters = viewFilter !== 'all' || capacityFilter !== '0' || 
    priceRange[0] !== 0 || priceRange[1] !== 10000 || 
    hasJacuzzi || hasFireplace || hasPool;

  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Konaklama"
            title="Bungalovlarımız"
            description="Doğanın içinde, modern konforla donatılmış premium bungalovlarımızı keşfedin."
          />
        </div>
      </section>

      {/* Filters & Listing */}
      <section className="section-padding pt-0">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          {/* Filter Toggle */}
          <div className="flex items-center justify-between mb-8">
            <p className="text-muted-foreground">
              <span className="font-semibold text-foreground">{filteredBungalows.length}</span> bungalov bulundu
            </p>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="gap-2"
            >
              <Filter className="w-4 h-4" />
              Filtreler
              {hasActiveFilters && (
                <span className="w-2 h-2 rounded-full bg-primary" />
              )}
            </Button>
          </div>

          {/* Filters Panel */}
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-card rounded-2xl p-6 mb-8 shadow-card"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-heading font-semibold text-lg">Filtrele</h3>
                {hasActiveFilters && (
                  <Button variant="ghost" size="sm" onClick={resetFilters}>
                    <X className="w-4 h-4 mr-1" />
                    Temizle
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* View Filter */}
                <div className="space-y-2">
                  <Label>Manzara</Label>
                  <Select value={viewFilter} onValueChange={setViewFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {viewOptions.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Capacity Filter */}
                <div className="space-y-2">
                  <Label>Kapasite</Label>
                  <Select value={capacityFilter} onValueChange={setCapacityFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {capacityOptions.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Price Range */}
                <div className="space-y-2 md:col-span-2">
                  <Label>
                    Fiyat Aralığı: ₺{priceRange[0].toLocaleString('tr-TR')} - ₺{priceRange[1].toLocaleString('tr-TR')}
                  </Label>
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    min={0}
                    max={10000}
                    step={500}
                    className="mt-4"
                  />
                </div>

                {/* Feature Toggles */}
                <div className="flex items-center justify-between md:col-span-2 lg:col-span-4 pt-4 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Switch
                      id="jacuzzi"
                      checked={hasJacuzzi}
                      onCheckedChange={setHasJacuzzi}
                    />
                    <Label htmlFor="jacuzzi" className="cursor-pointer">Jakuzi</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="fireplace"
                      checked={hasFireplace}
                      onCheckedChange={setHasFireplace}
                    />
                    <Label htmlFor="fireplace" className="cursor-pointer">Şömine</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="pool"
                      checked={hasPool}
                      onCheckedChange={setHasPool}
                    />
                    <Label htmlFor="pool" className="cursor-pointer">Özel Havuz</Label>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Bungalow Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-card rounded-2xl overflow-hidden">
                  <Skeleton className="aspect-[4/3] w-full" />
                  <div className="p-5 space-y-3">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-2/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredBungalows.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
              {filteredBungalows.map((bungalow, index) => (
                <BungalowCard key={bungalow.id} bungalow={bungalow} index={index} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-muted-foreground text-lg mb-4">
                Arama kriterlerinize uygun bungalov bulunamadı.
              </p>
              <Button variant="outline" onClick={resetFilters}>
                Filtreleri Temizle
              </Button>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default Bungalows;
