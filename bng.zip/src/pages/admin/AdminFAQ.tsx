import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface FAQ {
  id: string;
  question: string;
  answer: string;
  display_order: number | null;
  is_active: boolean | null;
}

const AdminFAQ = () => {
  const { toast } = useToast();
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingFaq, setEditingFaq] = useState<Partial<FAQ> | null>(null);
  const [saving, setSaving] = useState(false);

  const fetchFaqs = async () => {
    const { data, error } = await supabase
      .from('faqs')
      .select('*')
      .order('display_order', { ascending: true });

    if (error) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } else {
      setFaqs(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchFaqs();
  }, []);

  const handleSave = async () => {
    if (!editingFaq?.question || !editingFaq?.answer) {
      toast({ title: 'Hata', description: 'Soru ve cevap zorunludur', variant: 'destructive' });
      return;
    }

    setSaving(true);

    try {
      if (editingFaq.id) {
        const { error } = await supabase
          .from('faqs')
          .update({
            question: editingFaq.question,
            answer: editingFaq.answer,
            display_order: editingFaq.display_order,
            is_active: editingFaq.is_active,
          })
          .eq('id', editingFaq.id);

        if (error) throw error;
        toast({ title: 'Başarılı', description: 'SSS güncellendi' });
      } else {
        const insertData = {
          question: editingFaq.question!,
          answer: editingFaq.answer!,
          display_order: editingFaq.display_order || 0,
          is_active: editingFaq.is_active !== false,
        };
        const { error } = await supabase.from('faqs').insert([insertData]);
        if (error) throw error;
        toast({ title: 'Başarılı', description: 'SSS eklendi' });
      }

      setDialogOpen(false);
      setEditingFaq(null);
      fetchFaqs();
    } catch (error: any) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Bu soruyu silmek istediğinize emin misiniz?')) return;

    const { error } = await supabase.from('faqs').delete().eq('id', id);

    if (error) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Başarılı', description: 'SSS silindi' });
      fetchFaqs();
    }
  };

  const openDialog = (faq?: FAQ) => {
    setEditingFaq(faq || { question: '', answer: '', display_order: 0, is_active: true });
    setDialogOpen(true);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground">SSS</h1>
            <p className="text-muted-foreground">Sıkça sorulan soruları yönetin</p>
          </div>
          <Button onClick={() => openDialog()} variant="premium">
            <Plus className="w-4 h-4 mr-2" />
            Yeni Soru
          </Button>
        </div>

        {loading ? (
          <div className="text-center py-12">Yükleniyor...</div>
        ) : faqs.length === 0 ? (
          <div className="text-center py-12 bg-card rounded-xl">
            <p className="text-muted-foreground mb-4">Henüz SSS eklenmemiş</p>
            <Button onClick={() => openDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              İlk Soruyu Ekle
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {faqs.map((faq) => (
              <div
                key={faq.id}
                className="bg-card rounded-xl p-4 flex items-start gap-4"
              >
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">{faq.question}</h3>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                    {faq.answer}
                  </p>
                  {!faq.is_active && (
                    <span className="text-xs text-destructive">Pasif</span>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => openDialog(faq)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:bg-destructive/10"
                    onClick={() => handleDelete(faq.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Edit Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingFaq?.id ? 'Soru Düzenle' : 'Yeni Soru'}
              </DialogTitle>
            </DialogHeader>

            {editingFaq && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Soru *</Label>
                  <Input
                    value={editingFaq.question || ''}
                    onChange={(e) =>
                      setEditingFaq({ ...editingFaq, question: e.target.value })
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label>Cevap *</Label>
                  <Textarea
                    value={editingFaq.answer || ''}
                    onChange={(e) =>
                      setEditingFaq({ ...editingFaq, answer: e.target.value })
                    }
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Sıra</Label>
                  <Input
                    type="number"
                    value={editingFaq.display_order || 0}
                    onChange={(e) =>
                      setEditingFaq({ ...editingFaq, display_order: parseInt(e.target.value) })
                    }
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Switch
                    checked={editingFaq.is_active !== false}
                    onCheckedChange={(v) =>
                      setEditingFaq({ ...editingFaq, is_active: v })
                    }
                  />
                  <Label>Aktif</Label>
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    İptal
                  </Button>
                  <Button variant="premium" onClick={handleSave} disabled={saving}>
                    {saving ? 'Kaydediliyor...' : 'Kaydet'}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
};

export default AdminFAQ;
