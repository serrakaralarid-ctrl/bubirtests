import { useState } from 'react';
import { useParams, Navigate, Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { useBungalowBySlug } from '@/hooks/useBungalows';
import { useSiteConfig, generateWhatsAppLink, generateReservationMessage } from '@/hooks/useSiteConfig';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import { motion } from 'framer-motion';
import { 
  Users, Bed, Bath, Maximize, Star, ChevronLeft, ChevronRight,
  Check, MapPin
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

const BungalowDetail = () => {
  const { slug } = useParams();
  const { data: bungalow, isLoading, error } = useBungalowBySlug(slug || '');
  const { config } = useSiteConfig();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [checkIn, setCheckIn] = useState<Date | undefined>();
  const [checkOut, setCheckOut] = useState<Date | undefined>();
  const [guests, setGuests] = useState(2);

  if (isLoading) {
    return (
      <Layout>
        <section className="pt-24 pb-16">
          <div className="container-premium px-4 sm:px-6 lg:px-8">
            <Skeleton className="h-6 w-64 mb-6" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <Skeleton className="aspect-[16/10] w-full rounded-2xl" />
                <Skeleton className="h-10 w-3/4" />
                <Skeleton className="h-24 w-full" />
              </div>
              <div className="lg:col-span-1">
                <Skeleton className="h-96 w-full rounded-2xl" />
              </div>
            </div>
          </div>
        </section>
      </Layout>
    );
  }

  if (!bungalow || error) {
    return <Navigate to="/bungalovlar" replace />;
  }

  const images = bungalow.images || [];
  const features = bungalow.features || [];
  const amenities = bungalow.amenities || [];

  const handleReservation = () => {
    const checkInStr = checkIn ? format(checkIn, 'dd.MM.yyyy', { locale: tr }) : '[TARİH SEÇİNİZ]';
    const checkOutStr = checkOut ? format(checkOut, 'dd.MM.yyyy', { locale: tr }) : '[TARİH SEÇİNİZ]';
    const message = generateReservationMessage(bungalow.name, checkInStr, checkOutStr, guests);
    window.open(generateWhatsAppLink(message, config.whatsapp), '_blank');
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <Layout>
      <section className="pt-24 pb-16">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm mb-6">
            <Link to="/" className="text-muted-foreground hover:text-primary">Ana Sayfa</Link>
            <span className="text-muted-foreground">/</span>
            <Link to="/bungalovlar" className="text-muted-foreground hover:text-primary">Bungalovlar</Link>
            <span className="text-muted-foreground">/</span>
            <span className="text-foreground font-medium">{bungalow.name}</span>
          </nav>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Images & Details */}
            <div className="lg:col-span-2 space-y-8">
              {/* Image Gallery */}
              <div className="relative rounded-2xl overflow-hidden aspect-[16/10]">
                {images.length > 0 ? (
                  <motion.img
                    key={currentImageIndex}
                    src={images[currentImageIndex]}
                    alt={bungalow.name}
                    className="w-full h-full object-cover"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                ) : (
                  <div className="w-full h-full bg-muted flex items-center justify-center">
                    <span className="text-muted-foreground">Görsel yok</span>
                  </div>
                )}
                
                {images.length > 1 && (
                  <>
                    {/* Navigation Arrows */}
                    <button
                      onClick={prevImage}
                      className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-background transition-colors"
                      aria-label="Önceki resim"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-background transition-colors"
                      aria-label="Sonraki resim"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>

                    {/* Thumbnails */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                      {images.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={cn(
                            'w-2 h-2 rounded-full transition-all',
                            index === currentImageIndex
                              ? 'bg-white w-6'
                              : 'bg-white/50 hover:bg-white/80'
                          )}
                          aria-label={`Resim ${index + 1}`}
                        />
                      ))}
                    </div>
                  </>
                )}

                {/* Badges */}
                <div className="absolute top-4 left-4 flex gap-2">
                  {bungalow.is_popular && (
                    <span className="px-3 py-1 bg-primary text-primary-foreground text-sm font-semibold rounded-full">
                      Popüler
                    </span>
                  )}
                </div>
              </div>

              {/* Title & Rating */}
              <div>
                <div className="flex items-start justify-between mb-4">
                  <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground">
                    {bungalow.name}
                  </h1>
                  <div className="flex items-center gap-2 bg-secondary px-3 py-2 rounded-lg">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-bold">{bungalow.rating}</span>
                    <span className="text-muted-foreground text-sm">({bungalow.review_count} yorum)</span>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="flex flex-wrap gap-4 mb-6">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Users className="w-5 h-5" />
                    <span>{bungalow.capacity} Kişilik</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Bed className="w-5 h-5" />
                    <span>{bungalow.bedrooms} Yatak Odası</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Bath className="w-5 h-5" />
                    <span>{bungalow.bathrooms} Banyo</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Maximize className="w-5 h-5" />
                    <span>{bungalow.size}m²</span>
                  </div>
                  {bungalow.view && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-5 h-5" />
                      <span className="capitalize">{bungalow.view} Manzarası</span>
                    </div>
                  )}
                </div>

                {/* Description */}
                <p className="text-muted-foreground leading-relaxed">
                  {bungalow.description}
                </p>
              </div>

              {/* Features */}
              {features.length > 0 && (
                <div className="bg-card rounded-2xl p-6">
                  <h2 className="font-heading text-xl font-semibold mb-4">Özellikler</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Check className="w-4 h-4 text-primary" />
                        </div>
                        <span className="text-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Amenities */}
              {amenities.length > 0 && (
                <div className="bg-card rounded-2xl p-6">
                  <h2 className="font-heading text-xl font-semibold mb-4">Olanaklar</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {amenities.map((amenity, index) => (
                      <div key={index} className="flex items-center gap-2 text-muted-foreground">
                        <Check className="w-4 h-4 text-primary" />
                        <span>{amenity}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - Booking */}
            <div className="lg:col-span-1">
              <div className="sticky top-28 bg-card rounded-2xl p-6 shadow-card space-y-6">
                {/* Price */}
                <div className="text-center pb-6 border-b border-border">
                  <div className="text-sm text-muted-foreground mb-1">Gecelik fiyat</div>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl font-bold text-primary">
                      ₺{Number(bungalow.price_per_night).toLocaleString('tr-TR')}
                    </span>
                    <span className="text-muted-foreground">/ gece</span>
                  </div>
                </div>

                {/* Check-in */}
                <div>
                  <label className="block text-sm font-medium mb-2">Giriş Tarihi</label>
                  <Calendar
                    mode="single"
                    selected={checkIn}
                    onSelect={setCheckIn}
                    disabled={(date) => date < new Date()}
                    locale={tr}
                    className="rounded-lg border w-full"
                  />
                </div>

                {/* Check-out */}
                <div>
                  <label className="block text-sm font-medium mb-2">Çıkış Tarihi</label>
                  <Calendar
                    mode="single"
                    selected={checkOut}
                    onSelect={setCheckOut}
                    disabled={(date) => date < (checkIn || new Date())}
                    locale={tr}
                    className="rounded-lg border w-full"
                  />
                </div>

                {/* Guests */}
                <div>
                  <label className="block text-sm font-medium mb-2">Misafir Sayısı</label>
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => setGuests(Math.max(1, guests - 1))}
                      className="w-10 h-10 rounded-lg border border-border flex items-center justify-center hover:bg-muted transition-colors"
                    >
                      -
                    </button>
                    <span className="text-xl font-semibold w-8 text-center">{guests}</span>
                    <button
                      onClick={() => setGuests(Math.min(bungalow.capacity, guests + 1))}
                      className="w-10 h-10 rounded-lg border border-border flex items-center justify-center hover:bg-muted transition-colors"
                    >
                      +
                    </button>
                    <span className="text-sm text-muted-foreground">/ max {bungalow.capacity}</span>
                  </div>
                </div>

                {/* CTA */}
                <Button
                  variant="whatsapp"
                  size="xl"
                  className="w-full"
                  onClick={handleReservation}
                >
                  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  WhatsApp ile Rezervasyon
                </Button>

                <p className="text-center text-sm text-muted-foreground">
                  Tarih seçip WhatsApp'a yönlendirileceksiniz
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BungalowDetail;
