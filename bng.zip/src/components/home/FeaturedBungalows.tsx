import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SectionHeader } from '@/components/common/SectionHeader';
import { BungalowCard } from '@/components/bungalow/BungalowCard';
import { usePopularBungalows } from '@/hooks/useBungalows';
import { Skeleton } from '@/components/ui/skeleton';

export const FeaturedBungalows = () => {
  const { data: popularBungalows, isLoading } = usePopularBungalows();

  return (
    <section className="section-padding bg-muted">
      <div className="container-premium">
        <SectionHeader
          badge="Öne Çıkanlar"
          title="En Popüler Bungalovlarımız"
          description="Misafirlerimizin en çok tercih ettiği, doğayla iç içe premium bungalovlarımızı keşfedin."
        />

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-card rounded-2xl overflow-hidden">
                <Skeleton className="aspect-[4/3] w-full" />
                <div className="p-5 space-y-3">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {popularBungalows?.map((bungalow, index) => (
              <BungalowCard key={bungalow.id} bungalow={bungalow} index={index} />
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <Link to="/bungalovlar">
            <Button variant="premium" size="lg">
              Tüm Bungalovları Gör
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};
