import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-forwarded-for, x-real-ip',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body = await req.json();
    const { ip_address, user_agent, path, action } = body;

    console.log(`Rate limit check for IP: ${ip_address}, path: ${path}, action: ${action}`);

    // Get security settings
    const { data: settings } = await supabase
      .from('security_settings')
      .select('key, value');

    const settingsMap: Record<string, string> = {};
    settings?.forEach((s: { key: string; value: string }) => {
      settingsMap[s.key] = s.value;
    });

    const rateLimit = parseInt(settingsMap['rate_limit_requests'] || '10');
    const windowSeconds = parseInt(settingsMap['rate_limit_window_seconds'] || '60');
    const banDurationMinutes = parseInt(settingsMap['ban_duration_minutes'] || '60');
    const enableAutoBan = settingsMap['enable_auto_ban'] !== 'false';
    const enableBotDetection = settingsMap['enable_bot_detection'] !== 'false';

    // Check if IP is already banned
    const { data: existingBan } = await supabase
      .from('ip_bans')
      .select('*')
      .eq('ip_address', ip_address)
      .eq('is_active', true)
      .or('expires_at.is.null,expires_at.gt.now()')
      .single();

    if (existingBan) {
      console.log(`IP ${ip_address} is banned`);
      return new Response(
        JSON.stringify({ 
          allowed: false, 
          reason: 'IP is banned',
          banned: true,
          expires_at: existingBan.expires_at
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 403 }
      );
    }

    // Bot detection based on user agent
    if (enableBotDetection && user_agent) {
      const botPatterns = [
        /bot/i, /crawler/i, /spider/i, /scraper/i,
        /curl/i, /wget/i, /python/i, /java/i,
        /headless/i, /phantom/i, /selenium/i
      ];
      
      const isBot = botPatterns.some(pattern => pattern.test(user_agent));
      
      if (isBot) {
        // Log bot detection
        await supabase.from('security_logs').insert({
          ip_address,
          event_type: 'bot_detected',
          details: { user_agent, path },
          user_agent,
          path
        });

        console.log(`Bot detected: ${ip_address}, UA: ${user_agent}`);
      }
    }

    // Get current window start time
    const windowStart = new Date(Date.now() - windowSeconds * 1000);

    // Count requests in current window
    const { data: trackingData, error: trackingError } = await supabase
      .from('request_tracking')
      .select('*')
      .eq('ip_address', ip_address)
      .gte('window_start', windowStart.toISOString())
      .order('window_start', { ascending: false })
      .limit(1);

    let requestCount = 1;

    if (trackingData && trackingData.length > 0) {
      requestCount = trackingData[0].request_count + 1;
      
      // Update existing record
      await supabase
        .from('request_tracking')
        .update({ request_count: requestCount })
        .eq('id', trackingData[0].id);
    } else {
      // Create new tracking record
      await supabase.from('request_tracking').insert({
        ip_address,
        request_count: 1,
        window_start: new Date().toISOString()
      });
    }

    console.log(`Request count for ${ip_address}: ${requestCount}/${rateLimit}`);

    // Check if rate limit exceeded
    if (requestCount > rateLimit) {
      // Log rate limit violation
      await supabase.from('security_logs').insert({
        ip_address,
        event_type: 'rate_limit',
        details: { request_count: requestCount, limit: rateLimit, path },
        user_agent,
        path
      });

      // Auto-ban if enabled
      if (enableAutoBan) {
        const expiresAt = banDurationMinutes === 0 
          ? null 
          : new Date(Date.now() + banDurationMinutes * 60 * 1000).toISOString();

        await supabase.from('ip_bans').insert({
          ip_address,
          reason: `Rate limit exceeded: ${requestCount} requests in ${windowSeconds} seconds`,
          ban_type: 'auto',
          expires_at: expiresAt
        });

        // Log ban
        await supabase.from('security_logs').insert({
          ip_address,
          event_type: 'ban',
          details: { 
            reason: 'rate_limit_exceeded', 
            request_count: requestCount, 
            ban_duration_minutes: banDurationMinutes 
          },
          user_agent,
          path
        });

        console.log(`IP ${ip_address} banned for ${banDurationMinutes} minutes`);

        return new Response(
          JSON.stringify({ 
            allowed: false, 
            reason: 'Rate limit exceeded - IP banned',
            banned: true,
            expires_at: expiresAt
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 429 }
        );
      }

      return new Response(
        JSON.stringify({ 
          allowed: false, 
          reason: 'Rate limit exceeded',
          banned: false,
          retry_after: windowSeconds
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 429 }
      );
    }

    // Clean up old tracking data periodically (1 in 100 requests)
    if (Math.random() < 0.01) {
      await supabase.rpc('cleanup_old_request_tracking');
    }

    return new Response(
      JSON.stringify({ 
        allowed: true, 
        remaining: rateLimit - requestCount,
        reset_in: windowSeconds
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Rate limit error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage, allowed: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
