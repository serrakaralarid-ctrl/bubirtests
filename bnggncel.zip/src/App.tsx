import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ScrollToTop } from "@/components/common/ScrollToTop";
import { DocumentHead } from "@/components/common/DocumentHead";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import Bungalows from "./pages/Bungalows";
import BungalowDetail from "./pages/BungalowDetail";
import About from "./pages/About";
import Services from "./pages/Services";
import Gallery from "./pages/Gallery";
import Contact from "./pages/Contact";
import FAQ from "./pages/FAQ";
import KVKK from "./pages/KVKK";
import CookiePolicy from "./pages/CookiePolicy";
import Location from "./pages/Location";
import AdminAuth from "./pages/AdminAuth";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminBungalows from "./pages/admin/AdminBungalows";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminGallery from "./pages/admin/AdminGallery";
import AdminFAQ from "./pages/admin/AdminFAQ";
import AdminSecurity from "./pages/admin/AdminSecurity";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <DocumentHead />
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/bungalovlar" element={<Bungalows />} />
            <Route path="/bungalovlar/:slug" element={<BungalowDetail />} />
            <Route path="/hakkimizda" element={<About />} />
            <Route path="/hizmetler" element={<Services />} />
            <Route path="/galeri" element={<Gallery />} />
            <Route path="/iletisim" element={<Contact />} />
            <Route path="/sss" element={<FAQ />} />
            <Route path="/kvkk" element={<KVKK />} />
            <Route path="/cerez-politikasi" element={<CookiePolicy />} />
            <Route path="/konum" element={<Location />} />
            <Route path="/admin/giris" element={<AdminAuth />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/bungalovlar" element={<AdminBungalows />} />
            <Route path="/admin/ayarlar" element={<AdminSettings />} />
            <Route path="/admin/galeri" element={<AdminGallery />} />
            <Route path="/admin/sss" element={<AdminFAQ />} />
            <Route path="/admin/guvenlik" element={<AdminSecurity />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
