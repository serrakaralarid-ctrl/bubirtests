export interface Review {
  id: string;
  name: string;
  avatar?: string;
  location: string;
  rating: number;
  date: string;
  comment: string;
  bungalowName: string;
}

export const reviews: Review[] = [
  {
    id: '1',
    name: 'Ayşe Yılmaz',
    location: 'İstanbul',
    rating: 5,
    date: '2024-11-15',
    comment: 'Hayatımda kaldığım en güzel yer! Doğanın içinde, huzurlu ve son derece temiz. Personel çok ilgili ve yardımsever. Kesinlikle tekrar geleceğiz.',
    bungalowName: 'Orman Kaçamağı',
  },
  {
    id: '2',
    name: 'Mehmet Kaya',
    location: 'Ankara',
    rating: 5,
    date: '2024-11-10',
    comment: 'Eşimle balayımızı burada geçirdik. Jakuzili suite muhteşemdi. Göl manzarası ve gün batımı unutulmazdı. Her şey mükemmeldi!',
    bungalowName: 'Göl Manzaralı Suite',
  },
  {
    id: '3',
    name: 'Zeynep Demir',
    location: 'İzmir',
    rating: 5,
    date: '2024-10-28',
    comment: 'Ailemle birlikte harika bir hafta sonu geçirdik. Çocuklar doğayla iç içe vakit geçirdi. Hijyen ve temizlik konusunda çok titizler. Teşekkürler!',
    bungalowName: 'Dağ Evi Premium',
  },
  {
    id: '4',
    name: 'Can Özkan',
    location: 'Bursa',
    rating: 5,
    date: '2024-10-20',
    comment: 'WhatsApp üzerinden rezervasyon çok kolaydı. Sorularıma anında cevap aldım. Bungalov tam beklediğim gibiydi, hatta daha iyisiydi!',
    bungalowName: 'Romantik Kabin',
  },
  {
    id: '5',
    name: 'Elif Şahin',
    location: 'Antalya',
    rating: 5,
    date: '2024-10-15',
    comment: 'Denize sıfır bungalov gerçekten denize sıfır! Sabah dalga sesleriyle uyanmak paha biçilemez. Plaj ekipmanları ve bisikletler süper bir detaydı.',
    bungalowName: 'Deniz Esintisi',
  },
  {
    id: '6',
    name: 'Burak Aydın',
    location: 'Konya',
    rating: 5,
    date: '2024-10-05',
    comment: 'Lüks villa bungalov inanılmazdı. Özel havuz, sinema odası, her şey düşünülmüş. Büyük aile toplantıları için ideal. 10/10!',
    bungalowName: 'Lüks Villa Bungalov',
  },
];
