import { useEffect, useState, useRef } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2, X, Upload, Link, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface Bungalow {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  short_description: string | null;
  capacity: number;
  bedrooms: number;
  bathrooms: number;
  size: number;
  price_per_night: number;
  images: string[];
  features: string[];
  amenities: string[];
  view: string | null;
  has_jacuzzi: boolean | null;
  has_fireplace: boolean | null;
  has_private_pool: boolean | null;
  is_popular: boolean | null;
  is_active: boolean | null;
  rating: number | null;
  review_count: number | null;
}

const emptyBungalow: Partial<Bungalow> = {
  name: '',
  slug: '',
  description: '',
  short_description: '',
  capacity: 2,
  bedrooms: 1,
  bathrooms: 1,
  size: 50,
  price_per_night: 0,
  images: [],
  features: [],
  amenities: [],
  view: 'orman',
  has_jacuzzi: false,
  has_fireplace: false,
  has_private_pool: false,
  is_popular: false,
  is_active: true,
  rating: 5,
  review_count: 0,
};

const AdminBungalows = () => {
  const { toast } = useToast();
  const [bungalows, setBungalows] = useState<Bungalow[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBungalow, setEditingBungalow] = useState<Partial<Bungalow> | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [imageUploadMode, setImageUploadMode] = useState<'url' | 'file'>('url');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !editingBungalow) return;

    setUploading(true);

    try {
      const uploadedUrls: string[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `bungalow-${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;

        const { data, error } = await supabase.storage
          .from('gallery')
          .upload(fileName, file);

        if (error) throw error;

        const { data: urlData } = supabase.storage
          .from('gallery')
          .getPublicUrl(fileName);

        uploadedUrls.push(urlData.publicUrl);
      }

      const currentImages = Array.isArray(editingBungalow.images) ? editingBungalow.images : [];
      setEditingBungalow({
        ...editingBungalow,
        images: [...currentImages, ...uploadedUrls],
      });

      toast({ title: 'Başarılı', description: `${uploadedUrls.length} resim yüklendi` });
    } catch (error: any) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeImage = (index: number) => {
    if (!editingBungalow) return;
    const currentImages = Array.isArray(editingBungalow.images) ? [...editingBungalow.images] : [];
    currentImages.splice(index, 1);
    setEditingBungalow({ ...editingBungalow, images: currentImages });
  };

  const fetchBungalows = async () => {
    const { data, error } = await supabase
      .from('bungalows')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } else {
      setBungalows(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchBungalows();
  }, []);

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/ğ/g, 'g')
      .replace(/ü/g, 'u')
      .replace(/ş/g, 's')
      .replace(/ı/g, 'i')
      .replace(/ö/g, 'o')
      .replace(/ç/g, 'c')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
  };

  const handleSave = async () => {
    if (!editingBungalow?.name) {
      toast({ title: 'Hata', description: 'Bungalov adı zorunludur', variant: 'destructive' });
      return;
    }

    setSaving(true);

    const slug = editingBungalow.slug || generateSlug(editingBungalow.name);
    
    // Prepare data without id field for both insert and update
    const bungalowData = {
      name: editingBungalow.name,
      slug,
      description: editingBungalow.description || null,
      short_description: editingBungalow.short_description || null,
      capacity: editingBungalow.capacity || 2,
      bedrooms: editingBungalow.bedrooms || 1,
      bathrooms: editingBungalow.bathrooms || 1,
      size: editingBungalow.size || 50,
      price_per_night: Number(editingBungalow.price_per_night) || 0,
      images: Array.isArray(editingBungalow.images) ? editingBungalow.images : [],
      features: Array.isArray(editingBungalow.features) ? editingBungalow.features : [],
      amenities: Array.isArray(editingBungalow.amenities) ? editingBungalow.amenities : [],
      view: editingBungalow.view || 'orman',
      has_jacuzzi: editingBungalow.has_jacuzzi || false,
      has_fireplace: editingBungalow.has_fireplace || false,
      has_private_pool: editingBungalow.has_private_pool || false,
      is_popular: editingBungalow.is_popular || false,
      is_active: editingBungalow.is_active !== false,
      rating: Number(editingBungalow.rating) || 5,
      review_count: Number(editingBungalow.review_count) || 0,
    };

    try {
      if (editingBungalow.id) {
        const { error } = await supabase
          .from('bungalows')
          .update(bungalowData)
          .eq('id', editingBungalow.id);

        if (error) throw error;
        toast({ title: 'Başarılı', description: 'Bungalov güncellendi' });
      } else {
        // For insert, generate a new UUID for id
        const insertData = {
          id: crypto.randomUUID(),
          ...bungalowData,
        };
        const { error } = await supabase.from('bungalows').insert([insertData]);
        if (error) throw error;
        toast({ title: 'Başarılı', description: 'Bungalov eklendi' });
      }

      setDialogOpen(false);
      setEditingBungalow(null);
      fetchBungalows();
    } catch (error: any) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Bu bungalovu silmek istediğinize emin misiniz?')) return;

    const { error } = await supabase.from('bungalows').delete().eq('id', id);

    if (error) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Başarılı', description: 'Bungalov silindi' });
      fetchBungalows();
    }
  };

  const openDialog = (bungalow?: Bungalow) => {
    setEditingBungalow(bungalow || { ...emptyBungalow });
    setDialogOpen(true);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground">Bungalovlar</h1>
            <p className="text-muted-foreground">Bungalovlarınızı yönetin</p>
          </div>
          <Button onClick={() => openDialog()} variant="premium">
            <Plus className="w-4 h-4 mr-2" />
            Yeni Bungalov
          </Button>
        </div>

        {loading ? (
          <div className="text-center py-12">Yükleniyor...</div>
        ) : bungalows.length === 0 ? (
          <div className="text-center py-12 bg-card rounded-xl">
            <p className="text-muted-foreground mb-4">Henüz bungalov eklenmemiş</p>
            <Button onClick={() => openDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              İlk Bungalovu Ekle
            </Button>
          </div>
        ) : (
          <div className="grid gap-4">
            {bungalows.map((bungalow) => (
              <div
                key={bungalow.id}
                className="bg-card rounded-xl p-4 flex items-center gap-4"
              >
                {bungalow.images?.[0] && (
                  <img
                    src={bungalow.images[0]}
                    alt={bungalow.name}
                    className="w-24 h-16 object-cover rounded-lg"
                  />
                )}
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">{bungalow.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {bungalow.capacity} kişi • ₺{bungalow.price_per_night}/gece
                    {!bungalow.is_active && <span className="text-destructive ml-2">• Pasif</span>}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => openDialog(bungalow)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:bg-destructive/10"
                    onClick={() => handleDelete(bungalow.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Edit Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingBungalow?.id ? 'Bungalov Düzenle' : 'Yeni Bungalov'}
              </DialogTitle>
            </DialogHeader>

            {editingBungalow && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Ad *</Label>
                    <Input
                      value={editingBungalow.name || ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, name: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Slug</Label>
                    <Input
                      value={editingBungalow.slug || ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, slug: e.target.value })
                      }
                      placeholder="Otomatik oluşturulur"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Kısa Açıklama</Label>
                  <Input
                    value={editingBungalow.short_description || ''}
                    onChange={(e) =>
                      setEditingBungalow({ ...editingBungalow, short_description: e.target.value })
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label>Açıklama</Label>
                  <Textarea
                    value={editingBungalow.description || ''}
                    onChange={(e) =>
                      setEditingBungalow({ ...editingBungalow, description: e.target.value })
                    }
                    rows={4}
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label>Kapasite</Label>
                    <Input
                      type="text"
                      value={editingBungalow.capacity ?? ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, capacity: parseInt(e.target.value) || 0 })
                      }
                      placeholder="2"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Yatak Odası</Label>
                    <Input
                      type="text"
                      value={editingBungalow.bedrooms ?? ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, bedrooms: parseInt(e.target.value) || 0 })
                      }
                      placeholder="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Banyo</Label>
                    <Input
                      type="text"
                      value={editingBungalow.bathrooms ?? ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, bathrooms: parseInt(e.target.value) || 0 })
                      }
                      placeholder="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Boyut (m²)</Label>
                    <Input
                      type="text"
                      value={editingBungalow.size ?? ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, size: parseInt(e.target.value) || 0 })
                      }
                      placeholder="50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label>Gecelik Fiyat (₺)</Label>
                    <Input
                      type="text"
                      value={editingBungalow.price_per_night ?? ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, price_per_night: parseFloat(e.target.value) || 0 })
                      }
                      placeholder="1500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Manzara</Label>
                    <Input
                      value={editingBungalow.view || ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, view: e.target.value })
                      }
                      placeholder="orman, göl, dağ, deniz"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Yıldız (örn: 4.3)</Label>
                    <Input
                      type="text"
                      value={editingBungalow.rating ?? ''}
                      onChange={(e) => {
                        const val = e.target.value.replace(',', '.');
                        setEditingBungalow({ 
                          ...editingBungalow, 
                          rating: val as any
                        });
                      }}
                      onBlur={(e) => {
                        const val = parseFloat(e.target.value.replace(',', '.'));
                        setEditingBungalow({ 
                          ...editingBungalow, 
                          rating: isNaN(val) ? null : val
                        });
                      }}
                      placeholder="4.5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Yorum Sayısı</Label>
                    <Input
                      type="text"
                      value={editingBungalow.review_count ?? ''}
                      onChange={(e) =>
                        setEditingBungalow({ ...editingBungalow, review_count: parseInt(e.target.value) || 0 })
                      }
                      placeholder="0"
                    />
                  </div>
                </div>

                {/* Image Upload Section */}
                <div className="space-y-3">
                  <Label>Resimler</Label>
                  
                  {/* Upload Mode Toggle */}
                  <div className="flex gap-2 p-1 bg-muted rounded-lg">
                    <Button
                      type="button"
                      variant={imageUploadMode === 'url' ? 'default' : 'ghost'}
                      size="sm"
                      className="flex-1"
                      onClick={() => setImageUploadMode('url')}
                    >
                      <Link className="w-4 h-4 mr-2" />
                      URL ile
                    </Button>
                    <Button
                      type="button"
                      variant={imageUploadMode === 'file' ? 'default' : 'ghost'}
                      size="sm"
                      className="flex-1"
                      onClick={() => setImageUploadMode('file')}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Dosya Yükle
                    </Button>
                  </div>

                  {imageUploadMode === 'url' ? (
                    <Textarea
                      value={typeof editingBungalow.images === 'string' 
                        ? editingBungalow.images 
                        : editingBungalow.images?.join(', ') || ''}
                      onChange={(e) =>
                        setEditingBungalow({
                          ...editingBungalow,
                          images: e.target.value as any,
                        })
                      }
                      onBlur={(e) =>
                        setEditingBungalow({
                          ...editingBungalow,
                          images: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                        })
                      }
                      placeholder="URL'leri virgülle ayırın"
                      rows={2}
                    />
                  ) : (
                    <div className="space-y-3">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
                      >
                        {uploading ? (
                          <div className="flex items-center justify-center gap-2">
                            <Loader2 className="w-6 h-6 animate-spin" />
                            <span>Yükleniyor...</span>
                          </div>
                        ) : (
                          <>
                            <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                            <p className="text-sm text-muted-foreground">
                              Tıklayın veya sürükleyin
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Birden fazla resim seçebilirsiniz
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Image Preview Grid */}
                  {Array.isArray(editingBungalow.images) && editingBungalow.images.length > 0 && (
                    <div className="grid grid-cols-4 gap-2 mt-3">
                      {editingBungalow.images.map((img, idx) => (
                        <div key={idx} className="relative group">
                          <img
                            src={img}
                            alt={`Resim ${idx + 1}`}
                            className="w-full aspect-square object-cover rounded-lg"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(idx)}
                            className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Özellikler (virgülle ayırın)</Label>
                  <Textarea
                    value={typeof editingBungalow.features === 'string'
                      ? editingBungalow.features
                      : editingBungalow.features?.join(', ') || ''}
                    onChange={(e) =>
                      setEditingBungalow({
                        ...editingBungalow,
                        features: e.target.value as any,
                      })
                    }
                    onBlur={(e) =>
                      setEditingBungalow({
                        ...editingBungalow,
                        features: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                      })
                    }
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Olanaklar (virgülle ayırın)</Label>
                  <Textarea
                    value={typeof editingBungalow.amenities === 'string'
                      ? editingBungalow.amenities
                      : editingBungalow.amenities?.join(', ') || ''}
                    onChange={(e) =>
                      setEditingBungalow({
                        ...editingBungalow,
                        amenities: e.target.value as any,
                      })
                    }
                    onBlur={(e) =>
                      setEditingBungalow({
                        ...editingBungalow,
                        amenities: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                      })
                    }
                    rows={2}
                  />
                </div>

                <div className="flex flex-wrap gap-6">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={editingBungalow.has_jacuzzi || false}
                      onCheckedChange={(v) =>
                        setEditingBungalow({ ...editingBungalow, has_jacuzzi: v })
                      }
                    />
                    <Label>Jakuzi</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={editingBungalow.has_fireplace || false}
                      onCheckedChange={(v) =>
                        setEditingBungalow({ ...editingBungalow, has_fireplace: v })
                      }
                    />
                    <Label>Şömine</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={editingBungalow.has_private_pool || false}
                      onCheckedChange={(v) =>
                        setEditingBungalow({ ...editingBungalow, has_private_pool: v })
                      }
                    />
                    <Label>Özel Havuz</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={editingBungalow.is_popular || false}
                      onCheckedChange={(v) =>
                        setEditingBungalow({ ...editingBungalow, is_popular: v })
                      }
                    />
                    <Label>Popüler</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={editingBungalow.is_active !== false}
                      onCheckedChange={(v) =>
                        setEditingBungalow({ ...editingBungalow, is_active: v })
                      }
                    />
                    <Label>Aktif</Label>
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    İptal
                  </Button>
                  <Button variant="premium" onClick={handleSave} disabled={saving}>
                    {saving ? 'Kaydediliyor...' : 'Kaydet'}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
};

export default AdminBungalows;
