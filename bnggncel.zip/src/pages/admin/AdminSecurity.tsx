import { useState, useEffect } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { 
  Shield, Ban, Clock, AlertTriangle, Activity, 
  Plus, Trash2, RefreshCw, Search, Download
} from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';

interface SecuritySetting {
  id: string;
  key: string;
  value: string | null;
}

interface IPBan {
  id: string;
  ip_address: string;
  reason: string | null;
  ban_type: string;
  banned_at: string;
  expires_at: string | null;
  is_active: boolean;
}

interface SecurityLog {
  id: string;
  ip_address: string;
  event_type: string;
  details: unknown;
  user_agent: string | null;
  path: string | null;
  created_at: string;
}

const AdminSecurity = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [bans, setBans] = useState<IPBan[]>([]);
  const [logs, setLogs] = useState<SecurityLog[]>([]);
  const [newBanIP, setNewBanIP] = useState('');
  const [newBanReason, setNewBanReason] = useState('');
  const [newBanDuration, setNewBanDuration] = useState('60');
  const [searchLog, setSearchLog] = useState('');
  const [logFilter, setLogFilter] = useState('all');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch settings
      const { data: settingsData } = await supabase
        .from('security_settings')
        .select('*');
      
      const settingsMap: Record<string, string> = {};
      settingsData?.forEach((s: SecuritySetting) => {
        settingsMap[s.key] = s.value || '';
      });
      setSettings(settingsMap);

      // Fetch bans
      const { data: bansData } = await supabase
        .from('ip_bans')
        .select('*')
        .order('banned_at', { ascending: false });
      setBans(bansData || []);

      // Fetch logs
      const { data: logsData } = await supabase
        .from('security_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      setLogs(logsData || []);

    } catch (error) {
      console.error('Error fetching security data:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      for (const [key, value] of Object.entries(settings)) {
        const { data: existing } = await supabase
          .from('security_settings')
          .select('id')
          .eq('key', key)
          .single();

        if (existing) {
          await supabase
            .from('security_settings')
            .update({ value, updated_at: new Date().toISOString() })
            .eq('key', key);
        } else {
          await supabase
            .from('security_settings')
            .insert({ key, value });
        }
      }
      toast({ title: 'Başarılı', description: 'Güvenlik ayarları kaydedildi' });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({ title: 'Hata', description: 'Ayarlar kaydedilemedi', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const addManualBan = async () => {
    if (!newBanIP.trim()) {
      toast({ title: 'Hata', description: 'IP adresi gerekli', variant: 'destructive' });
      return;
    }

    try {
      const expiresAt = parseInt(newBanDuration) === 0 
        ? null 
        : new Date(Date.now() + parseInt(newBanDuration) * 60 * 1000).toISOString();

      const { error } = await supabase.from('ip_bans').insert({
        ip_address: newBanIP.trim(),
        reason: newBanReason || 'Manuel ban',
        ban_type: 'manual',
        expires_at: expiresAt
      });

      if (error) throw error;

      toast({ title: 'Başarılı', description: 'IP adresi banlandı' });
      setNewBanIP('');
      setNewBanReason('');
      fetchData();
    } catch (error) {
      console.error('Error adding ban:', error);
      toast({ title: 'Hata', description: 'Ban eklenemedi', variant: 'destructive' });
    }
  };

  const removeBan = async (id: string) => {
    try {
      const { error } = await supabase
        .from('ip_bans')
        .update({ is_active: false })
        .eq('id', id);

      if (error) throw error;

      toast({ title: 'Başarılı', description: 'Ban kaldırıldı' });
      fetchData();
    } catch (error) {
      console.error('Error removing ban:', error);
      toast({ title: 'Hata', description: 'Ban kaldırılamadı', variant: 'destructive' });
    }
  };

  const deleteBan = async (id: string) => {
    try {
      const { error } = await supabase
        .from('ip_bans')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({ title: 'Başarılı', description: 'Ban silindi' });
      fetchData();
    } catch (error) {
      console.error('Error deleting ban:', error);
      toast({ title: 'Hata', description: 'Ban silinemedi', variant: 'destructive' });
    }
  };

  const exportLogs = () => {
    const csvContent = [
      ['Tarih', 'IP Adresi', 'Olay Tipi', 'Path', 'User Agent', 'Detaylar'].join(','),
      ...filteredLogs.map(log => [
        format(new Date(log.created_at), 'dd.MM.yyyy HH:mm:ss'),
        log.ip_address,
        log.event_type,
        log.path || '',
        `"${(log.user_agent || '').replace(/"/g, '""')}"`,
        `"${JSON.stringify(log.details || {}).replace(/"/g, '""')}"`
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `security-logs-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    link.click();
  };

  const filteredLogs = logs.filter(log => {
    const matchesSearch = searchLog === '' || 
      log.ip_address.includes(searchLog) ||
      log.event_type.includes(searchLog) ||
      (log.path && log.path.includes(searchLog));
    
    const matchesFilter = logFilter === 'all' || log.event_type === logFilter;
    
    return matchesSearch && matchesFilter;
  });

  const getEventTypeBadge = (type: string) => {
    const variants: Record<string, { variant: 'default' | 'destructive' | 'secondary' | 'outline'; label: string }> = {
      'rate_limit': { variant: 'destructive', label: 'Rate Limit' },
      'ban': { variant: 'destructive', label: 'Ban' },
      'suspicious': { variant: 'secondary', label: 'Şüpheli' },
      'brute_force': { variant: 'destructive', label: 'Brute Force' },
      'bot_detected': { variant: 'outline', label: 'Bot' }
    };
    const config = variants[type] || { variant: 'default' as const, label: type };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-heading font-bold flex items-center gap-2">
              <Shield className="w-7 h-7 text-primary" />
              Güvenlik
            </h1>
            <p className="text-muted-foreground">Site güvenlik ayarlarını yönetin</p>
          </div>
          <Button onClick={fetchData} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Yenile
          </Button>
        </div>

        <Tabs defaultValue="settings" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              <span className="hidden sm:inline">Ayarlar</span>
            </TabsTrigger>
            <TabsTrigger value="bans" className="flex items-center gap-2">
              <Ban className="w-4 h-4" />
              <span className="hidden sm:inline">IP Banları</span>
              {bans.filter(b => b.is_active).length > 0 && (
                <Badge variant="destructive" className="ml-1">
                  {bans.filter(b => b.is_active).length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="logs" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              <span className="hidden sm:inline">Loglar</span>
            </TabsTrigger>
            <TabsTrigger value="stats" className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              <span className="hidden sm:inline">İstatistikler</span>
            </TabsTrigger>
          </TabsList>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {/* Rate Limiting */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    İstek Limitleme
                  </CardTitle>
                  <CardDescription>
                    Aynı IP'den gelen istek sayısını sınırlayın
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Maksimum İstek Sayısı</Label>
                    <Input
                      type="number"
                      value={settings['rate_limit_requests'] || '10'}
                      onChange={(e) => setSettings({ ...settings, rate_limit_requests: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">Dakikada izin verilen maksimum istek</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Zaman Penceresi (saniye)</Label>
                    <Input
                      type="number"
                      value={settings['rate_limit_window_seconds'] || '60'}
                      onChange={(e) => setSettings({ ...settings, rate_limit_window_seconds: e.target.value })}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Auto Ban */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Ban className="w-5 h-5" />
                    Otomatik Ban
                  </CardTitle>
                  <CardDescription>
                    Limit aşıldığında otomatik banlama ayarları
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Otomatik Ban Aktif</Label>
                    <Switch
                      checked={settings['enable_auto_ban'] !== 'false'}
                      onCheckedChange={(checked) => setSettings({ ...settings, enable_auto_ban: String(checked) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Ban Süresi (dakika)</Label>
                    <Input
                      type="number"
                      value={settings['ban_duration_minutes'] || '60'}
                      onChange={(e) => setSettings({ ...settings, ban_duration_minutes: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">0 = Kalıcı ban</p>
                  </div>
                </CardContent>
              </Card>

              {/* Bot Detection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    Bot Tespiti
                  </CardTitle>
                  <CardDescription>
                    Otomatik bot ve script tespiti
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Bot Tespiti Aktif</Label>
                    <Switch
                      checked={settings['enable_bot_detection'] !== 'false'}
                      onCheckedChange={(checked) => setSettings({ ...settings, enable_bot_detection: String(checked) })}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Brute Force */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Brute Force Koruması
                  </CardTitle>
                  <CardDescription>
                    Giriş denemelerini sınırlayın
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Maksimum Deneme</Label>
                    <Input
                      type="number"
                      value={settings['brute_force_attempts'] || '5'}
                      onChange={(e) => setSettings({ ...settings, brute_force_attempts: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Deneme Penceresi (dakika)</Label>
                    <Input
                      type="number"
                      value={settings['brute_force_window_minutes'] || '15'}
                      onChange={(e) => setSettings({ ...settings, brute_force_window_minutes: e.target.value })}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* CAPTCHA */}
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>CAPTCHA Ayarları</CardTitle>
                  <CardDescription>
                    Şüpheli davranışlarda CAPTCHA göster
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>CAPTCHA Aktif</Label>
                    <Switch
                      checked={settings['enable_captcha'] !== 'false'}
                      onCheckedChange={(checked) => setSettings({ ...settings, enable_captcha: String(checked) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>CAPTCHA Eşiği (başarısız deneme sayısı)</Label>
                    <Input
                      type="number"
                      value={settings['captcha_threshold'] || '5'}
                      onChange={(e) => setSettings({ ...settings, captcha_threshold: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">
                      Bu sayıda başarısız denemeden sonra CAPTCHA gösterilir
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Button onClick={saveSettings} disabled={saving} className="w-full md:w-auto">
              {saving ? 'Kaydediliyor...' : 'Ayarları Kaydet'}
            </Button>
          </TabsContent>

          {/* IP Bans Tab */}
          <TabsContent value="bans" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Manuel Ban Ekle</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <Label>IP Adresi</Label>
                    <Input
                      placeholder="192.168.1.1"
                      value={newBanIP}
                      onChange={(e) => setNewBanIP(e.target.value)}
                    />
                  </div>
                  <div className="flex-1">
                    <Label>Sebep</Label>
                    <Input
                      placeholder="Ban sebebi (opsiyonel)"
                      value={newBanReason}
                      onChange={(e) => setNewBanReason(e.target.value)}
                    />
                  </div>
                  <div className="w-full md:w-40">
                    <Label>Süre (dakika)</Label>
                    <Input
                      type="number"
                      placeholder="60"
                      value={newBanDuration}
                      onChange={(e) => setNewBanDuration(e.target.value)}
                    />
                  </div>
                  <div className="flex items-end">
                    <Button onClick={addManualBan}>
                      <Plus className="w-4 h-4 mr-2" />
                      Ekle
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Aktif Banlar</CardTitle>
                <CardDescription>
                  {bans.filter(b => b.is_active).length} aktif ban
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>IP Adresi</TableHead>
                      <TableHead>Tip</TableHead>
                      <TableHead>Sebep</TableHead>
                      <TableHead>Ban Tarihi</TableHead>
                      <TableHead>Bitiş</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead className="text-right">İşlem</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bans.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground">
                          Henüz ban bulunmuyor
                        </TableCell>
                      </TableRow>
                    ) : (
                      bans.map((ban) => (
                        <TableRow key={ban.id}>
                          <TableCell className="font-mono">{ban.ip_address}</TableCell>
                          <TableCell>
                            <Badge variant={ban.ban_type === 'auto' ? 'secondary' : 'default'}>
                              {ban.ban_type === 'auto' ? 'Otomatik' : 'Manuel'}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate">{ban.reason || '-'}</TableCell>
                          <TableCell>
                            {format(new Date(ban.banned_at), 'dd.MM.yyyy HH:mm', { locale: tr })}
                          </TableCell>
                          <TableCell>
                            {ban.expires_at 
                              ? format(new Date(ban.expires_at), 'dd.MM.yyyy HH:mm', { locale: tr })
                              : <Badge variant="destructive">Kalıcı</Badge>
                            }
                          </TableCell>
                          <TableCell>
                            <Badge variant={ban.is_active ? 'destructive' : 'outline'}>
                              {ban.is_active ? 'Aktif' : 'Pasif'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              {ban.is_active && (
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => removeBan(ban.id)}
                                >
                                  Kaldır
                                </Button>
                              )}
                              <Button 
                                variant="destructive" 
                                size="sm"
                                onClick={() => deleteBan(ban.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Güvenlik Logları</CardTitle>
                    <CardDescription>Son 100 güvenlik olayı</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="IP veya path ara..."
                        value={searchLog}
                        onChange={(e) => setSearchLog(e.target.value)}
                        className="pl-9 w-[200px]"
                      />
                    </div>
                    <select
                      value={logFilter}
                      onChange={(e) => setLogFilter(e.target.value)}
                      className="h-10 px-3 rounded-md border bg-background"
                    >
                      <option value="all">Tümü</option>
                      <option value="rate_limit">Rate Limit</option>
                      <option value="ban">Ban</option>
                      <option value="bot_detected">Bot</option>
                      <option value="brute_force">Brute Force</option>
                      <option value="suspicious">Şüpheli</option>
                    </select>
                    <Button variant="outline" onClick={exportLogs}>
                      <Download className="w-4 h-4 mr-2" />
                      Dışa Aktar
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tarih</TableHead>
                      <TableHead>IP Adresi</TableHead>
                      <TableHead>Olay</TableHead>
                      <TableHead>Path</TableHead>
                      <TableHead>Detaylar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-muted-foreground">
                          Henüz log bulunmuyor
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="whitespace-nowrap">
                            {format(new Date(log.created_at), 'dd.MM.yyyy HH:mm:ss', { locale: tr })}
                          </TableCell>
                          <TableCell className="font-mono">{log.ip_address}</TableCell>
                          <TableCell>{getEventTypeBadge(log.event_type)}</TableCell>
                          <TableCell className="max-w-[150px] truncate">{log.path || '-'}</TableCell>
                          <TableCell className="max-w-[200px]">
                            {log.details ? (
                              <code className="text-xs bg-muted px-1 py-0.5 rounded">
                                {JSON.stringify(log.details).slice(0, 50)}...
                              </code>
                            ) : '-'}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats Tab */}
          <TabsContent value="stats" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Aktif Banlar
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-destructive">
                    {bans.filter(b => b.is_active).length}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Rate Limit İhlalleri (Bugün)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-orange-500">
                    {logs.filter(l => 
                      l.event_type === 'rate_limit' && 
                      new Date(l.created_at).toDateString() === new Date().toDateString()
                    ).length}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Bot Tespitleri (Bugün)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-yellow-500">
                    {logs.filter(l => 
                      l.event_type === 'bot_detected' && 
                      new Date(l.created_at).toDateString() === new Date().toDateString()
                    ).length}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Toplam Olay (Bugün)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {logs.filter(l => 
                      new Date(l.created_at).toDateString() === new Date().toDateString()
                    ).length}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Son Saldırı Özeti</CardTitle>
                <CardDescription>
                  En çok rate limit ihlali yapan IP adresleri
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(
                    logs
                      .filter(l => l.event_type === 'rate_limit')
                      .reduce((acc, log) => {
                        acc[log.ip_address] = (acc[log.ip_address] || 0) + 1;
                        return acc;
                      }, {} as Record<string, number>)
                  )
                    .sort(([, a], [, b]) => b - a)
                    .slice(0, 5)
                    .map(([ip, count]) => (
                      <div key={ip} className="flex items-center justify-between">
                        <span className="font-mono">{ip}</span>
                        <Badge variant="destructive">{count} ihlal</Badge>
                      </div>
                    ))
                  }
                  {logs.filter(l => l.event_type === 'rate_limit').length === 0 && (
                    <p className="text-muted-foreground text-center">Henüz ihlal bulunmuyor</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
};

export default AdminSecurity;
