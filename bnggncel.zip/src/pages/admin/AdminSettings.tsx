import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Save, Loader2 } from 'lucide-react';

interface ConfigItem {
  id: string;
  key: string;
  value: string;
}

const configFields = [
  { key: 'site_name', label: 'Site Adı', type: 'text' },
  { key: 'site_tagline', label: 'Slogan', type: 'text' },
  { key: 'site_description', label: 'Site Açıklaması', type: 'textarea' },
  { key: 'phone', label: 'Telefon', type: 'text' },
  { key: 'whatsapp', label: 'WhatsApp Numarası (905xxxxxxxxx)', type: 'text' },
  { key: 'email', label: 'E-posta', type: 'email' },
  { key: 'address', label: 'Adres', type: 'textarea' },
  { key: 'working_hours', label: 'Çalışma Saatleri', type: 'text' },
  { key: 'instagram', label: 'Instagram URL', type: 'url' },
  { key: 'facebook', label: 'Facebook URL', type: 'url' },
  { key: 'twitter', label: 'Twitter URL', type: 'url' },
  { key: 'google_maps_url', label: 'Google Maps URL', type: 'url' },
  { key: 'coordinates_lat', label: 'Enlem (Latitude)', type: 'text' },
  { key: 'coordinates_lng', label: 'Boylam (Longitude)', type: 'text' },
  { key: 'logo_url', label: 'Logo URL', type: 'url' },
];

const AdminSettings = () => {
  const { toast } = useToast();
  const [configItems, setConfigItems] = useState<ConfigItem[]>([]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    const { data, error } = await supabase.from('site_config').select('id, key, value');

    if (error) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } else if (data) {
      setConfigItems(data.map(item => ({ id: item.id, key: item.key, value: item.value || '' })));
      const valuesObj: Record<string, string> = {};
      data.forEach((item) => {
        valuesObj[item.key] = item.value || '';
      });
      setValues(valuesObj);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    setSaving(true);

    try {
      for (const [key, value] of Object.entries(values)) {
        const existingItem = configItems.find(item => item.key === key);
        
        if (existingItem) {
          // Update existing record
          const { error } = await supabase
            .from('site_config')
            .update({ value, updated_at: new Date().toISOString() })
            .eq('id', existingItem.id);

          if (error) throw error;
        } else {
          // Insert new record
          const { error } = await supabase
            .from('site_config')
            .insert({ key, value, updated_at: new Date().toISOString() });

          if (error) throw error;
        }
      }

      // Refresh data after save
      await fetchConfig();
      toast({ title: 'Başarılı', description: 'Ayarlar kaydedildi' });
    } catch (error: any) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const updateValue = (key: string, value: string) => {
    setValues(prev => ({ ...prev, [key]: value }));
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-3xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground">Site Ayarları</h1>
            <p className="text-muted-foreground">Site bilgilerini düzenleyin</p>
          </div>
          <Button variant="premium" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Kaydet
          </Button>
        </div>

        <div className="bg-card rounded-xl p-6 space-y-6">
          {/* Genel Bilgiler */}
          <div>
            <h2 className="font-semibold text-lg text-foreground mb-4">Genel Bilgiler</h2>
            <div className="grid gap-4">
              {configFields.slice(0, 3).map((field) => (
                <div key={field.key} className="space-y-2">
                  <Label>{field.label}</Label>
                  {field.type === 'textarea' ? (
                    <Textarea
                      value={values[field.key] || ''}
                      onChange={(e) => updateValue(field.key, e.target.value)}
                      rows={3}
                    />
                  ) : (
                    <Input
                      type={field.type}
                      value={values[field.key] || ''}
                      onChange={(e) => updateValue(field.key, e.target.value)}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* İletişim Bilgileri */}
          <div>
            <h2 className="font-semibold text-lg text-foreground mb-4">İletişim Bilgileri</h2>
            <div className="grid gap-4">
              {configFields.slice(3, 8).map((field) => (
                <div key={field.key} className="space-y-2">
                  <Label>{field.label}</Label>
                  {field.type === 'textarea' ? (
                    <Textarea
                      value={values[field.key] || ''}
                      onChange={(e) => updateValue(field.key, e.target.value)}
                      rows={2}
                    />
                  ) : (
                    <Input
                      type={field.type}
                      value={values[field.key] || ''}
                      onChange={(e) => updateValue(field.key, e.target.value)}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Sosyal Medya */}
          <div>
            <h2 className="font-semibold text-lg text-foreground mb-4">Sosyal Medya</h2>
            <div className="grid gap-4">
              {configFields.slice(8, 11).map((field) => (
                <div key={field.key} className="space-y-2">
                  <Label>{field.label}</Label>
                  <Input
                    type={field.type}
                    value={values[field.key] || ''}
                    onChange={(e) => updateValue(field.key, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Konum */}
          <div>
            <h2 className="font-semibold text-lg text-foreground mb-4">Konum</h2>
            <div className="grid gap-4">
              {configFields.slice(11, 14).map((field) => (
                <div key={field.key} className="space-y-2">
                  <Label>{field.label}</Label>
                  <Input
                    type={field.type}
                    value={values[field.key] || ''}
                    onChange={(e) => updateValue(field.key, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Logo */}
          <div>
            <h2 className="font-semibold text-lg text-foreground mb-4">Logo</h2>
            <div className="space-y-2">
              <Label>Logo URL</Label>
              <Input
                type="url"
                value={values['logo_url'] || ''}
                onChange={(e) => updateValue('logo_url', e.target.value)}
                placeholder="https://..."
              />
              {values['logo_url'] && (
                <div className="mt-2">
                  <img
                    src={values['logo_url']}
                    alt="Logo Preview"
                    className="max-h-16 object-contain"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminSettings;
