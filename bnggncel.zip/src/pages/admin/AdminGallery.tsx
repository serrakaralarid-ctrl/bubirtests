import { useEffect, useState, useRef } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2, Upload, Link, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

interface GalleryImage {
  id: string;
  url: string;
  title: string | null;
  category: string | null;
  display_order: number | null;
  is_active: boolean | null;
}

const categories = [
  { value: 'bungalov', label: 'Bungalovlar' },
  { value: 'interior', label: 'İç Mekan' },
  { value: 'nature', label: 'Doğa' },
  { value: 'other', label: 'Diğer' },
];

const AdminGallery = () => {
  const { toast } = useToast();
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingImage, setEditingImage] = useState<Partial<GalleryImage> | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadMode, setUploadMode] = useState<'url' | 'file'>('url');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);

    try {
      const uploadedUrls: string[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;

        const { data, error } = await supabase.storage
          .from('gallery')
          .upload(fileName, file);

        if (error) throw error;

        const { data: urlData } = supabase.storage
          .from('gallery')
          .getPublicUrl(fileName);

        uploadedUrls.push(urlData.publicUrl);
      }

      // If single file and dialog is open, set the URL
      if (uploadedUrls.length === 1 && editingImage) {
        setEditingImage({ ...editingImage, url: uploadedUrls[0] });
        toast({ title: 'Başarılı', description: 'Resim yüklendi' });
      } else {
        // Multiple files - create gallery entries for each
        for (const url of uploadedUrls) {
          await supabase.from('gallery_images').insert([{
            url,
            title: null,
            category: 'bungalov',
            display_order: 0,
            is_active: true,
          }]);
        }
        toast({ title: 'Başarılı', description: `${uploadedUrls.length} resim yüklendi` });
        fetchImages();
        setDialogOpen(false);
      }
    } catch (error: any) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const fetchImages = async () => {
    const { data, error } = await supabase
      .from('gallery_images')
      .select('*')
      .order('display_order', { ascending: true });

    if (error) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } else {
      setImages(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchImages();
  }, []);

  const handleSave = async () => {
    if (!editingImage?.url) {
      toast({ title: 'Hata', description: 'URL zorunludur', variant: 'destructive' });
      return;
    }

    setSaving(true);

    try {
      if (editingImage.id) {
        const { error } = await supabase
          .from('gallery_images')
          .update({
            url: editingImage.url,
            title: editingImage.title,
            category: editingImage.category,
            display_order: editingImage.display_order,
            is_active: editingImage.is_active,
          })
          .eq('id', editingImage.id);

        if (error) throw error;
        toast({ title: 'Başarılı', description: 'Resim güncellendi' });
      } else {
        const insertData = {
          url: editingImage.url!,
          title: editingImage.title || null,
          category: editingImage.category || 'bungalov',
          display_order: editingImage.display_order || 0,
          is_active: editingImage.is_active !== false,
        };
        console.log('Inserting gallery image:', insertData);
        const { data, error } = await supabase.from('gallery_images').insert([insertData]).select();
        console.log('Insert result:', { data, error });
        if (error) throw error;
        toast({ title: 'Başarılı', description: 'Resim eklendi' });
      }

      setDialogOpen(false);
      setEditingImage(null);
      fetchImages();
    } catch (error: any) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Bu resmi silmek istediğinize emin misiniz?')) return;

    const { error } = await supabase.from('gallery_images').delete().eq('id', id);

    if (error) {
      toast({ title: 'Hata', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Başarılı', description: 'Resim silindi' });
      fetchImages();
    }
  };

  const openDialog = (image?: GalleryImage) => {
    setEditingImage(
      image || { url: '', title: '', category: 'bungalov', display_order: 0, is_active: true }
    );
    setDialogOpen(true);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground">Galeri</h1>
            <p className="text-muted-foreground">Galeri fotoğraflarını yönetin</p>
          </div>
          <Button onClick={() => openDialog()} variant="premium">
            <Plus className="w-4 h-4 mr-2" />
            Yeni Resim
          </Button>
        </div>

        {loading ? (
          <div className="text-center py-12">Yükleniyor...</div>
        ) : images.length === 0 ? (
          <div className="text-center py-12 bg-card rounded-xl">
            <p className="text-muted-foreground mb-4">Henüz resim eklenmemiş</p>
            <Button onClick={() => openDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              İlk Resmi Ekle
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {images.map((image) => (
              <div
                key={image.id}
                className="bg-card rounded-xl overflow-hidden group relative"
              >
                <img
                  src={image.url}
                  alt={image.title || 'Galeri resmi'}
                  className="w-full aspect-square object-cover"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => openDialog(image)}
                  >
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(image.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                {!image.is_active && (
                  <div className="absolute top-2 left-2 bg-destructive text-destructive-foreground text-xs px-2 py-1 rounded">
                    Pasif
                  </div>
                )}
                <div className="p-2">
                  <p className="text-sm font-medium truncate">{image.title || 'İsimsiz'}</p>
                  <p className="text-xs text-muted-foreground">
                    {categories.find((c) => c.value === image.category)?.label || image.category}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Edit Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingImage?.id ? 'Resim Düzenle' : 'Yeni Resim'}
              </DialogTitle>
            </DialogHeader>

            {editingImage && (
              <div className="space-y-4">
                {/* Upload Mode Toggle */}
                <div className="flex gap-2 p-1 bg-muted rounded-lg">
                  <Button
                    type="button"
                    variant={uploadMode === 'url' ? 'default' : 'ghost'}
                    size="sm"
                    className="flex-1"
                    onClick={() => setUploadMode('url')}
                  >
                    <Link className="w-4 h-4 mr-2" />
                    URL ile
                  </Button>
                  <Button
                    type="button"
                    variant={uploadMode === 'file' ? 'default' : 'ghost'}
                    size="sm"
                    className="flex-1"
                    onClick={() => setUploadMode('file')}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Dosya Yükle
                  </Button>
                </div>

                {uploadMode === 'url' ? (
                  <div className="space-y-2">
                    <Label>URL *</Label>
                    <Input
                      value={editingImage.url || ''}
                      onChange={(e) =>
                        setEditingImage({ ...editingImage, url: e.target.value })
                      }
                      placeholder="https://..."
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>Resim Yükle (Limit yok)</Label>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors"
                    >
                      {uploading ? (
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="w-6 h-6 animate-spin" />
                          <span>Yükleniyor...</span>
                        </div>
                      ) : (
                        <>
                          <Upload className="w-10 h-10 mx-auto mb-2 text-muted-foreground" />
                          <p className="text-sm text-muted-foreground">
                            Tıklayın veya sürükleyin
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Birden fazla resim seçebilirsiniz
                          </p>
                        </>
                      )}
                    </div>
                    {editingImage.url && (
                      <div className="mt-3">
                        <p className="text-sm text-muted-foreground mb-2">Yüklenen resim:</p>
                        <img
                          src={editingImage.url}
                          alt="Yüklenen resim önizlemesi"
                          className="max-h-32 object-contain rounded-lg border border-border"
                        />
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-2">
                  <Label>Başlık</Label>
                  <Input
                    value={editingImage.title || ''}
                    onChange={(e) =>
                      setEditingImage({ ...editingImage, title: e.target.value })
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label>Kategori</Label>
                  <Select
                    value={editingImage.category || 'bungalov'}
                    onValueChange={(v) =>
                      setEditingImage({ ...editingImage, category: v })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Sıra</Label>
                  <Input
                    type="number"
                    value={editingImage.display_order || 0}
                    onChange={(e) =>
                      setEditingImage({ ...editingImage, display_order: parseInt(e.target.value) })
                    }
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Switch
                    checked={editingImage.is_active !== false}
                    onCheckedChange={(v) =>
                      setEditingImage({ ...editingImage, is_active: v })
                    }
                  />
                  <Label>Aktif</Label>
                </div>

                {editingImage.url && (
                  <div>
                    <Label>Önizleme</Label>
                    <img
                      src={editingImage.url}
                      alt="Preview"
                      className="mt-2 max-h-40 object-contain rounded-lg"
                    />
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    İptal
                  </Button>
                  <Button variant="premium" onClick={handleSave} disabled={saving}>
                    {saving ? 'Kaydediliyor...' : 'Kaydet'}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
};

export default AdminGallery;
