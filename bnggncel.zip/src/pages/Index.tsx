import { Layout } from '@/components/layout/Layout';
import { HeroSection } from '@/components/home/HeroSection';
import { FeaturedBungalows } from '@/components/home/FeaturedBungalows';
import { ReviewsSection } from '@/components/home/ReviewsSection';
import { TrustSection } from '@/components/home/TrustSection';
import { CTASection } from '@/components/home/CTASection';

const Index = () => {
  return (
    <Layout>
      <HeroSection />
      <FeaturedBungalows />
      <TrustSection />
      <ReviewsSection />
      <CTASection />
    </Layout>
  );
};

export default Index;
