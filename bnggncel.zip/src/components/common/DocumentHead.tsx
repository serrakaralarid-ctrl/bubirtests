import { useEffect } from 'react';
import { useSiteConfig } from '@/hooks/useSiteConfig';

export const DocumentHead = () => {
  const { config } = useSiteConfig();

  useEffect(() => {
    // Update document title
    document.title = `${config.name} | ${config.tagline}`;

    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', config.description);
    }

    // Update OG tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute('content', `${config.name} | ${config.tagline}`);
    }

    const ogDescription = document.querySelector('meta[property="og:description"]');
    if (ogDescription) {
      ogDescription.setAttribute('content', config.description);
    }

    // Update Twitter tags
    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (twitterTitle) {
      twitterTitle.setAttribute('content', `${config.name} | ${config.tagline}`);
    }

    const twitterDescription = document.querySelector('meta[name="twitter:description"]');
    if (twitterDescription) {
      twitterDescription.setAttribute('content', config.description);
    }
  }, [config]);

  return null;
};
