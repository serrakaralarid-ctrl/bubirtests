import { Link } from 'react-router-dom';
import { Users, Bed, Star, Maximize, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Bungalow } from '@/hooks/useBungalows';
import { useSiteConfig, generateWhatsAppLink, generateReservationMessage } from '@/hooks/useSiteConfig';
import useEmblaCarousel from 'embla-carousel-react';

interface BungalowCardProps {
  bungalow: Bungalow;
  index?: number;
}

export const BungalowCard = ({ bungalow, index = 0 }: BungalowCardProps) => {
  const { config } = useSiteConfig();
  const whatsappLink = generateWhatsAppLink(
    generateReservationMessage(bungalow.name, '[TARİH]', '[TARİH]', bungalow.capacity),
    config.whatsapp
  );

  const allImages = bungalow.images?.length ? bungalow.images : ['/placeholder.svg'];
  const images = allImages.slice(0, 5); // Maksimum 5 resim göster
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, dragFree: false });
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollPrev = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    emblaApi?.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    emblaApi?.scrollNext();
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    
    const onSelect = () => {
      setSelectedIndex(emblaApi.selectedScrollSnap());
    };
    
    emblaApi.on('select', onSelect);
    onSelect(); // Initial call
    
    return () => {
      emblaApi.off('select', onSelect);
    };
  }, [emblaApi]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group bg-card rounded-2xl overflow-hidden shadow-card hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
    >
      {/* Image Carousel */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <div className="overflow-hidden h-full" ref={emblaRef}>
          <div className="flex h-full">
            {images.map((image, imgIndex) => (
              <div key={imgIndex} className="flex-[0_0_100%] min-w-0 h-full">
                <img
                  src={image}
                  alt={`${bungalow.name} - ${imgIndex + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Navigation Arrows */}
        {images.length > 1 && (
          <>
            <button
              onClick={scrollPrev}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={scrollNext}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Dots Indicator */}
        {images.length > 1 && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {images.map((_, dotIndex) => (
              <button
                key={dotIndex}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  emblaApi?.scrollTo(dotIndex);
                }}
                className={`w-2 h-2 rounded-full transition-all ${
                  dotIndex === selectedIndex 
                    ? 'bg-white w-4' 
                    : 'bg-white/50 hover:bg-white/75'
                }`}
              />
            ))}
          </div>
        )}

        {/* Badges */}
        <div className="absolute top-4 left-4 flex gap-2">
          {bungalow.is_popular && (
            <span className="px-3 py-1 bg-primary text-primary-foreground text-xs font-semibold rounded-full">
              Popüler
            </span>
          )}
          {bungalow.has_jacuzzi && (
            <span className="px-3 py-1 bg-foreground/80 text-background text-xs font-semibold rounded-full">
              Jakuzi
            </span>
          )}
        </div>
        {/* Rating */}
        <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 bg-background/90 backdrop-blur-sm rounded-lg">
          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-semibold">{bungalow.rating}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-heading font-semibold text-lg text-foreground group-hover:text-primary transition-colors">
            {bungalow.name}
          </h3>
        </div>
        
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
          {bungalow.short_description}
        </p>

        {/* Features */}
        <div className="flex items-center gap-4 mb-4 text-muted-foreground text-sm">
          <div className="flex items-center gap-1.5">
            <Users className="w-4 h-4" />
            <span>{bungalow.capacity} Kişi</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Bed className="w-4 h-4" />
            <span>{bungalow.bedrooms} Yatak</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Maximize className="w-4 h-4" />
            <span>{bungalow.size}m²</span>
          </div>
        </div>

        {/* Price & Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div>
            <span className="text-2xl font-bold text-primary">
              ₺{Number(bungalow.price_per_night).toLocaleString('tr-TR')}
            </span>
            <span className="text-muted-foreground text-sm"> / gece</span>
          </div>
          <div className="flex gap-2">
            <Link to={`/bungalovlar/${bungalow.slug}`}>
              <Button variant="outline" size="sm">
                Detay
              </Button>
            </Link>
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button variant="whatsapp" size="sm">
                Rezervasyon
              </Button>
            </a>
          </div>
        </div>
      </div>
    </motion.div>
  );
};