import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface RateLimitState {
  isBlocked: boolean;
  isBanned: boolean;
  remaining: number;
  retryAfter: number | null;
  expiresAt: string | null;
}

interface RateLimitResult {
  allowed: boolean;
  banned?: boolean;
  remaining?: number;
  retry_after?: number;
  expires_at?: string | null;
  reason?: string;
}

export const useRateLimit = () => {
  const [state, setState] = useState<RateLimitState>({
    isBlocked: false,
    isBanned: false,
    remaining: 10,
    retryAfter: null,
    expiresAt: null
  });

  const checkRateLimit = useCallback(async (path?: string): Promise<boolean> => {
    try {
      // Get IP address (will be captured by edge function from headers)
      const userAgent = navigator.userAgent;
      
      const { data, error } = await supabase.functions.invoke<RateLimitResult>('rate-limit', {
        body: {
          ip_address: 'client', // Edge function will get real IP from headers
          user_agent: userAgent,
          path: path || window.location.pathname,
          action: 'check'
        }
      });

      if (error) {
        console.error('Rate limit check error:', error);
        return true; // Allow on error to prevent blocking legitimate users
      }

      if (data) {
        setState({
          isBlocked: !data.allowed,
          isBanned: data.banned || false,
          remaining: data.remaining || 0,
          retryAfter: data.retry_after || null,
          expiresAt: data.expires_at || null
        });

        return data.allowed;
      }

      return true;
    } catch (err) {
      console.error('Rate limit error:', err);
      return true;
    }
  }, []);

  const resetState = useCallback(() => {
    setState({
      isBlocked: false,
      isBanned: false,
      remaining: 10,
      retryAfter: null,
      expiresAt: null
    });
  }, []);

  return {
    ...state,
    checkRateLimit,
    resetState
  };
};
