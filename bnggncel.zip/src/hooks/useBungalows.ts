import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Tables } from '@/integrations/supabase/types';

export type Bungalow = Tables<'bungalows'>;

export const useBungalows = () => {
  return useQuery({
    queryKey: ['bungalows'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('bungalows')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Bungalow[];
    },
  });
};

export const usePopularBungalows = () => {
  return useQuery({
    queryKey: ['bungalows', 'popular'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('bungalows')
        .select('*')
        .eq('is_active', true)
        .eq('is_popular', true)
        .order('rating', { ascending: false })
        .limit(3);

      if (error) throw error;
      return data as Bungalow[];
    },
  });
};

export const useBungalowBySlug = (slug: string) => {
  return useQuery({
    queryKey: ['bungalows', slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('bungalows')
        .select('*')
        .eq('slug', slug)
        .eq('is_active', true)
        .maybeSingle();

      if (error) throw error;
      return data as Bungalow | null;
    },
    enabled: !!slug,
  });
};
