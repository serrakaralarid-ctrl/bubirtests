import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface SiteConfig {
  name: string;
  tagline: string;
  description: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  workingHours: string;
  socialMedia: {
    instagram: string;
    facebook: string;
    twitter: string;
  };
  googleMapsUrl: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  logoUrl: string;
}

const defaultConfig: SiteConfig = {
  name: 'Zen Bungalov',
  tagline: 'Doğanın Kalbinde Lüks Konaklama',
  description: 'Türkiye\'nin en güzel doğal güzelliklerinde, modern konfor ve doğanın buluştuğu premium bungalov deneyimi.',
  phone: '',
  whatsapp: '',
  email: 'info@zenbungalov.com',
  address: 'Sapanca Gölü Mevkii, No: 42, Sapanca / Sakarya',
  workingHours: '',
  socialMedia: {
    instagram: '#',
    facebook: '#',
    twitter: '#',
  },
  googleMapsUrl: 'https://maps.google.com/?q=40.6892,29.8867',
  coordinates: {
    lat: 40.6892,
    lng: 29.8867,
  },
  logoUrl: '',
};

export const useSiteConfig = () => {
  const [config, setConfig] = useState<SiteConfig>(defaultConfig);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchConfig = async () => {
      const { data, error } = await supabase.from('site_config').select('key, value');

      if (!error && data) {
        const configObj: SiteConfig = { ...defaultConfig };
        
        data.forEach((item) => {
          switch (item.key) {
            case 'site_name':
              configObj.name = item.value || defaultConfig.name;
              break;
            case 'site_tagline':
              configObj.tagline = item.value || defaultConfig.tagline;
              break;
            case 'site_description':
              configObj.description = item.value || defaultConfig.description;
              break;
            case 'phone':
              configObj.phone = item.value || defaultConfig.phone;
              break;
            case 'whatsapp':
              configObj.whatsapp = item.value || defaultConfig.whatsapp;
              break;
            case 'email':
              configObj.email = item.value || defaultConfig.email;
              break;
            case 'address':
              configObj.address = item.value || defaultConfig.address;
              break;
            case 'working_hours':
              configObj.workingHours = item.value || defaultConfig.workingHours;
              break;
            case 'instagram':
              configObj.socialMedia.instagram = item.value || defaultConfig.socialMedia.instagram;
              break;
            case 'facebook':
              configObj.socialMedia.facebook = item.value || defaultConfig.socialMedia.facebook;
              break;
            case 'twitter':
              configObj.socialMedia.twitter = item.value || defaultConfig.socialMedia.twitter;
              break;
            case 'google_maps_url':
              configObj.googleMapsUrl = item.value || defaultConfig.googleMapsUrl;
              break;
            case 'coordinates_lat':
              configObj.coordinates.lat = parseFloat(item.value || '') || defaultConfig.coordinates.lat;
              break;
            case 'coordinates_lng':
              configObj.coordinates.lng = parseFloat(item.value || '') || defaultConfig.coordinates.lng;
              break;
            case 'logo_url':
              configObj.logoUrl = item.value || '';
              break;
          }
        });

        setConfig(configObj);
      }
      setLoading(false);
    };

    fetchConfig();
  }, []);

  return { config, loading };
};

export const generateWhatsAppLink = (message: string, whatsapp?: string): string => {
  const encodedMessage = encodeURIComponent(message);
  const number = whatsapp || '905321234567';
  return `https://wa.me/${number}?text=${encodedMessage}`;
};

export const generateReservationMessage = (
  bungalowName: string,
  checkIn: string,
  checkOut: string,
  guests: number
): string => {
  return `Merhaba, rezervasyon yapmak istiyorum:

Bungalov: ${bungalowName}
Giriş: ${checkIn}
Çıkış: ${checkOut}
Kişi: ${guests}

Ad Soyad:
Telefon:`;
};
