import { motion } from 'framer-motion';
import { Shield, Sparkles, Clock, HeartHandshake, Wifi, Car } from 'lucide-react';
import { SectionHeader } from '@/components/common/SectionHeader';

const features = [
  {
    icon: Shield,
    title: 'Güvenli & Hijyenik',
    description: 'Tüm bungalovlarımız düzenli dezenfekte edilir ve hijyen standartlarına uygun olarak hazırlanır.',
  },
  {
    icon: Sparkles,
    title: 'Premium Kalite',
    description: 'En kaliteli malzemeler ve mobilyalarla donatılmış, konforlu yaşam alanları.',
  },
  {
    icon: Clock,
    title: '7/24 Destek',
    description: 'WhatsApp üzerinden her an ulaşabileceğiniz müşteri hizmetleri.',
  },
  {
    icon: HeartHandshake,
    title: 'Kişisel Hizmet',
    description: 'Size özel karşılama ve ihtiyaçlarınıza göre düzenlenen özel hizmetler.',
  },
  {
    icon: Wifi,
    title: 'Yüksek Hızlı İnternet',
    description: 'Tüm bungalovlarda kesintisiz ve yüksek hızlı fiber internet bağlantısı.',
  },
  {
    icon: Car,
    title: 'Ücretsiz Otopark',
    description: 'Her bungalov için ayrılmış özel ve güvenli otopark alanı.',
  },
];

export const TrustSection = () => {
  return (
    <section className="section-padding bg-secondary">
      <div className="container-premium">
        <SectionHeader
          badge="Neden Biz?"
          title="Güvenle Konaklayın"
          description="Misafirlerimizin konforunu ve güvenliğini ön planda tutuyoruz."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group bg-background rounded-2xl p-6 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                <feature.icon className="w-7 h-7 text-primary group-hover:text-primary-foreground transition-colors" />
              </div>
              <h3 className="font-heading font-semibold text-lg text-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
