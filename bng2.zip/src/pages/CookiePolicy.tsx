import { Layout } from '@/components/layout/Layout';
import { SectionHeader } from '@/components/common/SectionHeader';
import { motion } from 'framer-motion';
import { useSiteConfig } from '@/hooks/useSiteConfig';

const CookiePolicy = () => {
  const { config } = useSiteConfig();

  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Yasal"
            title="Çerez Politikası"
            description="Web sitemizde kullanılan çerezler hakkında bilgilendirme."
          />
        </div>
      </section>

      {/* Content */}
      <section className="section-padding pt-0">
        <div className="container-premium px-4 sm:px-6 lg:px-8 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="bg-card rounded-2xl p-6 md:p-8 shadow-card space-y-8">
              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">Çerez Nedir?</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Çerezler, web sitemizi ziyaret ettiğinizde tarayıcınız aracılığıyla cihazınıza (bilgisayar, tablet, 
                  akıllı telefon vb.) kaydedilen küçük metin dosyalarıdır. Bu dosyalar, sizi tanımamıza ve tercihlerinizi 
                  hatırlamamıza yardımcı olur, böylece size daha iyi bir kullanıcı deneyimi sunabiliriz.
                </p>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">Kullandığımız Çerez Türleri</h2>
                
                <div className="space-y-6">
                  <div className="bg-secondary/50 rounded-xl p-5">
                    <h3 className="font-semibold text-foreground mb-2">1. Zorunlu Çerezler</h3>
                    <p className="text-muted-foreground text-sm">
                      Web sitemizin düzgün çalışması için gerekli olan çerezlerdir. Bu çerezler olmadan site 
                      işlevlerinin çoğu kullanılamaz. Oturum yönetimi ve güvenlik için kullanılır.
                    </p>
                  </div>

                  <div className="bg-secondary/50 rounded-xl p-5">
                    <h3 className="font-semibold text-foreground mb-2">2. Performans Çerezleri</h3>
                    <p className="text-muted-foreground text-sm">
                      Ziyaretçilerin siteyi nasıl kullandığını anlamamıza yardımcı olur. Sayfa görüntüleme sayısı, 
                      ziyaret süresi gibi istatistiksel veriler toplar. Bu veriler anonim olarak işlenir.
                    </p>
                  </div>

                  <div className="bg-secondary/50 rounded-xl p-5">
                    <h3 className="font-semibold text-foreground mb-2">3. İşlevsellik Çerezleri</h3>
                    <p className="text-muted-foreground text-sm">
                      Tercihlerinizi (dil seçimi, bölge vb.) hatırlamamıza olanak tanır. Size kişiselleştirilmiş 
                      bir deneyim sunmak için kullanılır.
                    </p>
                  </div>

                  <div className="bg-secondary/50 rounded-xl p-5">
                    <h3 className="font-semibold text-foreground mb-2">4. Pazarlama Çerezleri</h3>
                    <p className="text-muted-foreground text-sm">
                      İlgi alanlarınıza göre reklamlar göstermek için kullanılır. Bu çerezler, ziyaret ettiğiniz 
                      web sitelerini izler ve bu bilgiyi reklam şirketleriyle paylaşır.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">Üçüncü Taraf Çerezleri</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Web sitemizde aşağıdaki üçüncü taraf hizmetleri kullanılmaktadır ve bu hizmetler kendi çerezlerini 
                  yerleştirebilir:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li><strong>Google Analytics:</strong> Site trafiği ve kullanıcı davranışı analizi</li>
                  <li><strong>Google Maps:</strong> Harita ve konum hizmetleri</li>
                  <li><strong>WhatsApp Widget:</strong> Anlık iletişim hizmeti</li>
                </ul>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">Çerezlerin Saklama Süresi</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Çerezler, türlerine göre farklı sürelerde saklanır:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2 mt-4">
                  <li><strong>Oturum Çerezleri:</strong> Tarayıcı kapatıldığında silinir</li>
                  <li><strong>Kalıcı Çerezler:</strong> Belirlenen süre sonunda (genellikle 1-2 yıl) veya siz sildiğinizde silinir</li>
                </ul>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">Çerezleri Yönetme ve Silme</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Çoğu web tarayıcısı, çerezleri otomatik olarak kabul eder ancak tarayıcı ayarlarınızı değiştirerek 
                  çerezleri reddedebilir veya silebilirsiniz. Çerezleri devre dışı bırakmak, web sitemizin bazı 
                  özelliklerinin düzgün çalışmamasına neden olabilir.
                </p>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Tarayıcınızda çerez ayarlarını değiştirmek için:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li><strong>Chrome:</strong> Ayarlar → Gizlilik ve güvenlik → Çerezler</li>
                  <li><strong>Firefox:</strong> Seçenekler → Gizlilik ve Güvenlik → Çerezler</li>
                  <li><strong>Safari:</strong> Tercihler → Gizlilik → Çerezler</li>
                  <li><strong>Edge:</strong> Ayarlar → Gizlilik ve hizmetler → Çerezler</li>
                </ul>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">Onayınız</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Web sitemizi kullanarak, zorunlu çerezlerin kullanımını kabul etmiş olursunuz. Zorunlu olmayan 
                  çerezler için, sitemizi ilk ziyaretinizde görüntülenen çerez bildirimi aracılığıyla onayınızı alırız. 
                  Tercihlerinizi istediğiniz zaman değiştirebilirsiniz.
                </p>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">İletişim</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Çerez politikamız hakkında sorularınız için bizimle <strong>{config.email}</strong> 
                  adresinden iletişime geçebilirsiniz.
                </p>
              </div>

              <div className="pt-6 border-t border-border">
                <p className="text-muted-foreground text-sm">
                  <strong>Son Güncelleme:</strong> Aralık 2024
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default CookiePolicy;
