import { Layout } from '@/components/layout/Layout';
import { SectionHeader } from '@/components/common/SectionHeader';
import { motion } from 'framer-motion';
import { MapPin, Car, Train, Plane, Bus, Navigation, Clock, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useSiteConfig, generateWhatsAppLink } from '@/hooks/useSiteConfig';

const transportOptions = [
  {
    icon: Plane,
    title: 'Havayolu',
    description: 'Sabiha Gökçen Havalimanı',
    details: [
      'Havalimanından tesisimize uzaklık: ~75 km',
      'Tahmini süre: 1 saat 15 dakika (trafiğe bağlı)',
      'Transfer hizmeti sunulmaktadır (rezervasyon gerekli)',
    ],
  },
  {
    icon: Train,
    title: 'Demiryolu',
    description: 'Sapanca Tren İstasyonu',
    details: [
      'İstasyondan tesisimize uzaklık: ~5 km',
      'YHT ile Ankara-İstanbul hattında ulaşım mümkün',
      'İstasyondan transfer hizmeti sunulmaktadır',
    ],
  },
  {
    icon: Bus,
    title: 'Otobüs',
    description: 'Sapanca Otogarı',
    details: [
      'İstanbul, Ankara ve diğer şehirlerden otobüs seferleri',
      'Otogardan tesisimize uzaklık: ~3 km',
      'Otogardan transfer imkanı mevcuttur',
    ],
  },
  {
    icon: Car,
    title: 'Özel Araç',
    description: 'TEM / D-100 Karayolu',
    details: [
      'İstanbul\'dan: TEM ile ~130 km (1.5 saat)',
      'Ankara\'dan: TEM ile ~280 km (3 saat)',
      'Ücretsiz özel otopark mevcuttur',
    ],
  },
];

const nearbyPlaces = [
  { name: 'Sapanca Gölü', distance: '500 m', type: 'Doğa' },
  { name: 'Maşukiye Şelaleleri', distance: '15 km', type: 'Doğa' },
  { name: 'Kartepe Kayak Merkezi', distance: '25 km', type: 'Aktivite' },
  { name: 'Sapanca Sahil Yürüyüş Yolu', distance: '1 km', type: 'Aktivite' },
  { name: 'Market', distance: '500 m', type: 'Alışveriş' },
  { name: 'Restoran / Kahvaltı', distance: '1 km', type: 'Yeme-İçme' },
  { name: 'Eczane', distance: '2 km', type: 'Sağlık' },
  { name: 'Hastane', distance: '8 km', type: 'Sağlık' },
];

const Location = () => {
  const { config } = useSiteConfig();

  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Konum"
            title="Konum & Ulaşım"
            description="Tesisimize nasıl ulaşabileceğiniz hakkında detaylı bilgi."
          />
        </div>
      </section>

      {/* Address & Map */}
      <section className="section-padding pt-0">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Address Card */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-card rounded-2xl p-6 md:p-8 shadow-card"
            >
              <div className="flex items-start gap-4 mb-6">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-7 h-7 text-primary" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-xl text-foreground mb-2">Adresimiz</h3>
                  <p className="text-muted-foreground">{config.address}</p>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-primary" />
                  <a href={`tel:${config.phone}`} className="text-foreground hover:text-primary transition-colors">
                    {config.phone}
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-primary" />
                  <span className="text-muted-foreground">Çalışma Saatleri: {config.workingHours}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={config.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1"
                >
                  <Button variant="premium" className="w-full">
                    <Navigation className="w-4 h-4 mr-2" />
                    Google Maps'te Aç
                  </Button>
                </a>
                <a href={generateWhatsAppLink('Merhaba, yol tarifi almak istiyorum.', config.whatsapp)} className="flex-1">
                  <Button variant="whatsapp" className="w-full">
                    <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current mr-2">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                    Yol Tarifi Al
                  </Button>
                </a>
              </div>
            </motion.div>

            {/* Map */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-card rounded-2xl overflow-hidden shadow-card h-[400px]"
            >
              <iframe
                src={`https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24250.0!2d${config.coordinates.lng}!3d${config.coordinates.lat}!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDQxJzIxLjEiTiAyOcKwNTMnMTIuMSJF!5e0!3m2!1str!2str!4v1234567890`}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Konum Haritası"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Transportation Options */}
      <section className="section-padding bg-secondary">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Ulaşım"
            title="Nasıl Gelebilirsiniz?"
            description="Farklı ulaşım seçenekleri ile tesisimize kolayca ulaşın."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {transportOptions.map((option, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-background rounded-2xl p-6 hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <option.icon className="w-7 h-7 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-heading font-semibold text-lg text-foreground mb-1">
                      {option.title}
                    </h3>
                    <p className="text-primary font-medium text-sm mb-3">{option.description}</p>
                    <ul className="space-y-2">
                      {option.details.map((detail, i) => (
                        <li key={i} className="text-muted-foreground text-sm flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Nearby Places */}
      <section className="section-padding">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Çevre"
            title="Yakın Çevre"
            description="Tesisimizin yakınında bulunan önemli noktalar."
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {nearbyPlaces.map((place, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="bg-card rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-foreground">{place.name}</h4>
                  <span className="text-primary font-semibold text-sm">{place.distance}</span>
                </div>
                <span className="inline-block px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-md">
                  {place.type}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Transfer CTA */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-2xl mx-auto"
          >
            <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4">
              Transfer Hizmeti
            </h2>
            <p className="text-primary-foreground/80 mb-6">
              Havalimanı, tren istasyonu veya otobüs terminalinden tesisimize VIP transfer hizmeti sunuyoruz. 
              Rahat ve güvenli bir yolculuk için rezervasyon sırasında belirtmeniz yeterli.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={generateWhatsAppLink('Merhaba, transfer hizmeti hakkında bilgi almak istiyorum.', config.whatsapp)}>
                <Button variant="hero" size="xl">
                  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current mr-2">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  Transfer Rezervasyonu
                </Button>
              </a>
              <a href={`tel:${config.phone}`}>
                <Button variant="hero-outline" size="xl" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
                  <Phone className="w-5 h-5 mr-2" />
                  Hemen Ara
                </Button>
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Location;
