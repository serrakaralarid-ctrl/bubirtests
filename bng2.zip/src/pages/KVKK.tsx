import { Layout } from '@/components/layout/Layout';
import { SectionHeader } from '@/components/common/SectionHeader';
import { motion } from 'framer-motion';
import { useSiteConfig } from '@/hooks/useSiteConfig';

const KVKK = () => {
  const { config } = useSiteConfig();

  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Yasal"
            title="KVKK Aydınlatma Metni"
            description="Kişisel Verilerin Korunması Kanunu kapsamında aydınlatma metni."
          />
        </div>
      </section>

      {/* Content */}
      <section className="section-padding pt-0">
        <div className="container-premium px-4 sm:px-6 lg:px-8 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="prose prose-lg max-w-none"
          >
            <div className="bg-card rounded-2xl p-6 md:p-8 shadow-card space-y-8">
              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">1. Veri Sorumlusu</h2>
                <p className="text-muted-foreground leading-relaxed">
                  6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, kişisel verileriniz; veri sorumlusu olarak 
                  {config.name} ("Şirket") tarafından aşağıda açıklanan kapsamda işlenebilecektir.
                </p>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">2. Kişisel Verilerin İşlenme Amacı</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Toplanan kişisel verileriniz, KVKK'da öngörülen temel ilkelere uygun olarak ve KVKK'nın 5. ve 6. 
                  maddelerinde belirtilen kişisel veri işleme şartları dahilinde aşağıdaki amaçlarla işlenebilecektir:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li>Rezervasyon ve konaklama hizmetlerinin sunulması</li>
                  <li>Müşteri ilişkileri yönetimi</li>
                  <li>İletişim faaliyetlerinin yürütülmesi</li>
                  <li>Hizmet kalitesinin artırılması</li>
                  <li>Yasal yükümlülüklerin yerine getirilmesi</li>
                  <li>Şirket güvenliğinin sağlanması</li>
                  <li>Faturalandırma ve muhasebe işlemleri</li>
                </ul>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">3. İşlenen Kişisel Veriler</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Şirketimiz tarafından aşağıdaki kişisel veriler işlenebilmektedir:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li><strong>Kimlik Bilgileri:</strong> Ad, soyad, T.C. kimlik numarası</li>
                  <li><strong>İletişim Bilgileri:</strong> Telefon numarası, e-posta adresi, adres</li>
                  <li><strong>Finansal Bilgiler:</strong> Banka hesap bilgileri, fatura bilgileri</li>
                  <li><strong>Konaklama Bilgileri:</strong> Giriş-çıkış tarihleri, tercihler, özel istekler</li>
                  <li><strong>Görsel Kayıtlar:</strong> Güvenlik kamerası görüntüleri</li>
                </ul>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">4. Kişisel Verilerin Aktarılması</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Toplanan kişisel verileriniz, KVKK'nın 8. ve 9. maddelerinde belirtilen kişisel veri işleme şartları 
                  çerçevesinde; yasal yükümlülüklerimizi yerine getirmek amacıyla kamu kurum ve kuruluşlarına, 
                  hizmet aldığımız iş ortaklarımıza, tedarikçilerimize ve yasal zorunluluk hallerinde ilgili mercilere aktarılabilecektir.
                </p>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">5. Kişisel Veri Toplamanın Yöntemi ve Hukuki Sebebi</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Kişisel verileriniz; web sitemiz, telefon, e-posta, WhatsApp ve yüz yüze görüşmeler aracılığıyla 
                  otomatik ve otomatik olmayan yöntemlerle toplanmaktadır. Bu veriler; sözleşmenin ifası, yasal 
                  yükümlülüklerimizin yerine getirilmesi ve meşru menfaatlerimiz hukuki sebeplerine dayanılarak işlenmektedir.
                </p>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">6. Kişisel Veri Sahibinin Hakları</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  KVKK'nın 11. maddesi uyarınca kişisel veri sahipleri olarak aşağıdaki haklara sahipsiniz:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li>Kişisel verilerinizin işlenip işlenmediğini öğrenme</li>
                  <li>Kişisel verileriniz işlenmişse buna ilişkin bilgi talep etme</li>
                  <li>Kişisel verilerinizin işlenme amacını ve bunların amacına uygun kullanılıp kullanılmadığını öğrenme</li>
                  <li>Yurt içinde veya yurt dışında kişisel verilerinizin aktarıldığı üçüncü kişileri bilme</li>
                  <li>Kişisel verilerinizin eksik veya yanlış işlenmiş olması hâlinde bunların düzeltilmesini isteme</li>
                  <li>KVKK'da öngörülen şartlar çerçevesinde kişisel verilerinizin silinmesini veya yok edilmesini isteme</li>
                  <li>İşlenen verilerin münhasıran otomatik sistemler vasıtasıyla analiz edilmesi suretiyle aleyhinize bir sonucun ortaya çıkmasına itiraz etme</li>
                  <li>Kişisel verilerinizin kanuna aykırı olarak işlenmesi sebebiyle zarara uğramanız hâlinde zararın giderilmesini talep etme</li>
                </ul>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">7. Başvuru Yöntemi</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Yukarıda belirtilen haklarınızı kullanmak için kimliğinizi tespit edici gerekli bilgiler ile KVKK'nın 
                  11. maddesinde belirtilen haklardan kullanmayı talep ettiğiniz hakkınıza yönelik açıklamalarınızı içeren 
                  talebinizi; <strong>{config.email}</strong> adresine e-posta göndererek veya {config.address} adresine yazılı olarak iletebilirsiniz.
                </p>
              </div>

              <div>
                <h2 className="font-heading text-xl font-semibold text-foreground mb-4">8. Veri Güvenliği</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Şirketimiz, kişisel verilerinizin güvenliğini sağlamak amacıyla gerekli her türlü teknik ve idari 
                  tedbirleri almaktadır. Kişisel verileriniz; yetkisiz erişime, kayba, değiştirilmeye veya ifşa edilmeye 
                  karşı güvence altına alınmıştır.
                </p>
              </div>

              <div className="pt-6 border-t border-border">
                <p className="text-muted-foreground text-sm">
                  <strong>Son Güncelleme:</strong> Aralık 2024
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default KVKK;
