import { Layout } from '@/components/layout/Layout';
import { SectionHeader } from '@/components/common/SectionHeader';
import { motion } from 'framer-motion';
import { Award, Users, TreePine, Heart, Shield, Clock } from 'lucide-react';
import { useSiteConfig } from '@/hooks/useSiteConfig';

const About = () => {
  const { config } = useSiteConfig();

  return (
    <Layout>
      {/* Hero */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?w=1920&auto=format&fit=crop&q=80"
            alt="Doğa manzarası"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-hero" />
        </div>
        <div className="relative z-10 container-premium px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto text-center text-white"
          >
            <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              Hakkımızda
            </h1>
            <p className="text-white/80 text-lg md:text-xl">
              2018'den beri doğa ve konforu bir araya getiren, unutulmaz tatil deneyimleri sunuyoruz.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story */}
      <section className="section-padding">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-block px-4 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-medium mb-4">
                Hikayemiz
              </span>
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
                Doğanın Kalbinde
                <br />
                Premium Konaklama
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                  {config.name}, 2018 yılında doğa ile modern konforu bir araya getirme hayaliyle kuruldu. 
                  Sapanca Gölü'nün eşsiz güzelliklerinin kucağında, misafirlerimize huzur dolu bir kaçamak 
                  sunmak için yola çıktık.
                </p>
                <p>
                  Her bir bungalovumuz, doğaya saygılı malzemelerle, çevreye minimum etki bırakacak şekilde 
                  inşa edildi. Modern mimarinin inceliklerini geleneksel ahşap estetiğiyle harmanlayarak, 
                  benzersiz konaklama mekanları yarattık.
                </p>
                <p>
                  Bugün, 500'den fazla mutlu misafirimizle gurur duyuyoruz. Her bir yorumunuz, 
                  bizi daha iyisini yapmaya teşvik ediyor.
                </p>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <img
                src="https://images.unsplash.com/photo-1587061949409-02df41d5e562?w=800&auto=format&fit=crop"
                alt="Bungalov"
                className="rounded-2xl shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-primary text-primary-foreground p-6 rounded-2xl shadow-lg">
                <div className="text-4xl font-bold">5+</div>
                <div className="text-sm opacity-80">Yıllık Tecrübe</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section-padding bg-secondary">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Değerlerimiz"
            title="Bizim İçin Önemli Olan"
            description="Her kararımızda bizi yönlendiren temel değerlerimiz."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: TreePine,
                title: 'Doğaya Saygı',
                description: 'Sürdürülebilir uygulamalarla doğayı koruyarak gelecek nesillere aktarıyoruz.',
              },
              {
                icon: Heart,
                title: 'Misafir Odaklılık',
                description: 'Her misafirimizi ailemizin bir parçası olarak görüyor, en iyisini sunuyoruz.',
              },
              {
                icon: Award,
                title: 'Kalite',
                description: 'Premium malzemeler ve titiz işçilikle mükemmelliği hedefliyoruz.',
              },
              {
                icon: Shield,
                title: 'Güvenlik',
                description: 'Misafirlerimizin güvenliği ve hijyeni en büyük önceliğimiz.',
              },
              {
                icon: Users,
                title: 'Topluluk',
                description: 'Yerel toplulukla iş birliği yaparak bölgeye değer katıyoruz.',
              },
              {
                icon: Clock,
                title: 'Sürekli Gelişim',
                description: 'Misafir geri bildirimlerini dinleyerek sürekli kendimizi geliştiriyoruz.',
              },
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-background rounded-2xl p-6 hover:shadow-lg transition-shadow"
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                  <value.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-foreground mb-2">
                  {value.title}
                </h3>
                <p className="text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Note */}
      <section className="section-padding">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-6">
                Sizi Ağırlamaktan Mutluluk Duyarız
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed mb-8">
                Ekibimiz, her misafirimize ev sahipliği yapmaktan büyük keyif alıyor. 
                Doğanın huzurunu ve modern konforun keyfini bir arada yaşamanız için 
                her detayı özenle planlıyoruz. Sorularınız için her zaman buradayız.
              </p>
              <p className="font-heading text-xl font-semibold text-primary">
                — {config.name} Ailesi
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
