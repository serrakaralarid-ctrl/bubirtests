import { Layout } from '@/components/layout/Layout';
import { SectionHeader } from '@/components/common/SectionHeader';
import { motion } from 'framer-motion';
import { 
  Utensils, Bike, TreePine, Camera, Fish, Tent, 
  Flame, Wine, Baby, Car, Sparkles, Waves 
} from 'lucide-react';

const services = [
  {
    icon: Utensils,
    title: 'Kahvaltı Servisi',
    description: 'Serpme köy kahvaltısı veya açık büfe seçenekleriyle güne enerjik başlayın.',
    price: 'Kişi başı ₺350',
  },
  {
    icon: Flame,
    title: 'Barbekü Seti',
    description: 'Tam donanımlı barbekü seti ve piknik masası ile açık havada mangal keyfi.',
    price: 'Ücretsiz',
  },
  {
    icon: Wine,
    title: 'Romantik Paket',
    description: 'Şarap, çikolata, çiçek ve mum ile özel günlerinizi kutlayın.',
    price: '₺1.500',
  },
  {
    icon: Bike,
    title: 'Bisiklet Kiralama',
    description: 'Doğa içinde bisiklet turları için kaliteli dağ bisikletleri.',
    price: 'Günlük ₺150',
  },
  {
    icon: Fish,
    title: 'Balık Tutma',
    description: 'Göl kenarında huzurlu bir balık tutma deneyimi için ekipman ve rehberlik.',
    price: 'Günlük ₺200',
  },
  {
    icon: TreePine,
    title: 'Doğa Yürüyüşü',
    description: 'Rehberli doğa yürüyüşleri ile bölgenin gizli güzelliklerini keşfedin.',
    price: 'Kişi başı ₺250',
  },
  {
    icon: Camera,
    title: 'Fotoğraf Turu',
    description: 'Profesyonel fotoğrafçı eşliğinde en güzel kareleri yakalayın.',
    price: '₺1.000',
  },
  {
    icon: Tent,
    title: 'Kamp Deneyimi',
    description: 'Glamping tarzı lüks çadır deneyimi ile yıldızların altında uyuyun.',
    price: 'Gece ₺800',
  },
  {
    icon: Baby,
    title: 'Çocuk Aktiviteleri',
    description: 'Oyun alanı ve çocuk animasyonları ile minikler için eğlence.',
    price: 'Ücretsiz',
  },
  {
    icon: Car,
    title: 'Transfer Hizmeti',
    description: 'Havalimanı veya otobüs terminalinden VIP transfer.',
    price: 'Tek yön ₺500',
  },
  {
    icon: Sparkles,
    title: 'Spa & Masaj',
    description: 'Profesyonel masaj hizmeti ile stresinizi atın.',
    price: 'Seans ₺600',
  },
  {
    icon: Waves,
    title: 'Kano & SUP',
    description: 'Göl üzerinde kano veya SUP board ile su sporları keyfi.',
    price: 'Saatlik ₺100',
  },
];

const Services = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Hizmetler"
            title="Hizmetler & Aktiviteler"
            description="Konaklamanızı daha da özel kılacak ek hizmetler ve aktiviteler."
          />
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding pt-0">
        <div className="container-premium px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className="group bg-card rounded-2xl p-6 hover:shadow-lg transition-all duration-300 border border-transparent hover:border-primary/20"
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary transition-colors">
                  <service.icon className="w-7 h-7 text-primary group-hover:text-primary-foreground transition-colors" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-foreground mb-2">
                  {service.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {service.description}
                </p>
                <span className="inline-block px-3 py-1 bg-secondary text-secondary-foreground rounded-full text-sm font-medium">
                  {service.price}
                </span>
              </motion.div>
            ))}
          </div>

          {/* Note */}
          <div className="mt-12 text-center">
            <p className="text-muted-foreground">
              Ek hizmetler için rezervasyon sırasında veya WhatsApp üzerinden bilgi alabilirsiniz.
            </p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Services;
