import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { supabase } from '@/integrations/supabase/client';
import { Building, Image, HelpCircle, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    bungalows: 0,
    gallery: 0,
    faqs: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      const [bungalowsRes, galleryRes, faqsRes] = await Promise.all([
        supabase.from('bungalows').select('id', { count: 'exact', head: true }),
        supabase.from('gallery_images').select('id', { count: 'exact', head: true }),
        supabase.from('faqs').select('id', { count: 'exact', head: true }),
      ]);

      setStats({
        bungalows: bungalowsRes.count || 0,
        gallery: galleryRes.count || 0,
        faqs: faqsRes.count || 0,
      });
    };

    fetchStats();
  }, []);

  const cards = [
    { 
      title: 'Bungalovlar', 
      count: stats.bungalows, 
      icon: Building, 
      href: '/admin/bungalovlar',
      color: 'bg-blue-500'
    },
    { 
      title: 'Galeri', 
      count: stats.gallery, 
      icon: Image, 
      href: '/admin/galeri',
      color: 'bg-green-500'
    },
    { 
      title: 'SSS', 
      count: stats.faqs, 
      icon: HelpCircle, 
      href: '/admin/sss',
      color: 'bg-purple-500'
    },
    { 
      title: 'Site Ayarları', 
      count: null, 
      icon: Settings, 
      href: '/admin/ayarlar',
      color: 'bg-orange-500'
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-heading text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Sitenizi yönetin ve içeriklerinizi düzenleyin.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {cards.map((card) => (
            <Link
              key={card.title}
              to={card.href}
              className="bg-card rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${card.color} rounded-xl flex items-center justify-center`}>
                  <card.icon className="w-6 h-6 text-white" />
                </div>
                {card.count !== null && (
                  <span className="text-3xl font-bold text-foreground">{card.count}</span>
                )}
              </div>
              <h3 className="font-medium text-foreground">{card.title}</h3>
              <p className="text-sm text-muted-foreground">Yönet →</p>
            </Link>
          ))}
        </div>

        <div className="bg-card rounded-xl p-6 shadow-sm">
          <h2 className="font-heading text-lg font-semibold mb-4">Hızlı Başlangıç</h2>
          <ul className="space-y-2 text-muted-foreground">
            <li>• Bungalov eklemek için <Link to="/admin/bungalovlar" className="text-primary hover:underline">Bungalovlar</Link> sayfasına gidin</li>
            <li>• Site bilgilerini düzenlemek için <Link to="/admin/ayarlar" className="text-primary hover:underline">Site Ayarları</Link> sayfasına gidin</li>
            <li>• Galeri fotoğrafları için <Link to="/admin/galeri" className="text-primary hover:underline">Galeri</Link> sayfasını kullanın</li>
            <li>• SSS eklemek/düzenlemek için <Link to="/admin/sss" className="text-primary hover:underline">SSS</Link> sayfasına gidin</li>
          </ul>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;
