export interface Bungalow {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDescription: string;
  capacity: number;
  bedrooms: number;
  bathrooms: number;
  size: number;
  pricePerNight: number;
  images: string[];
  features: string[];
  amenities: string[];
  view: 'orman' | 'göl' | 'dağ' | 'deniz';
  hasJacuzzi: boolean;
  hasFireplace: boolean;
  hasPrivatePool: boolean;
  isPopular: boolean;
  rating: number;
  reviewCount: number;
}

export const bungalows: Bungalow[] = [
  {
    id: '1',
    name: 'Orman Kaçamağı',
    slug: 'orman-kacamagi',
    description: 'Doğanın kalbinde, huzurlu bir kaçamak için tasarlanmış premium bungalovumuz. Geniş cam yüzeyleri ile ormanın büyüleyici manzarasını yaşam alanınıza taşıyın. Modern konforu doğayla buluşturan bu özel mekanda unutulmaz anılar biriktirin.',
    shortDescription: 'Ormanın kalbinde huzurlu bir kaçamak',
    capacity: 4,
    bedrooms: 2,
    bathrooms: 1,
    size: 65,
    pricePerNight: 2500,
    images: [
      'https://images.unsplash.com/photo-1587061949409-02df41d5e562?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1618767689160-da3fb810aad7?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1521401830884-6c03c1c87ebb?w=800&auto=format&fit=crop',
    ],
    features: ['Panoramik Orman Manzarası', 'Özel Teras', 'Şömine', 'King Size Yatak'],
    amenities: ['WiFi', 'Klima', 'Mini Buzdolabı', 'Kahve Makinesi', 'Saç Kurutma', 'Güvenli Kasa'],
    view: 'orman',
    hasJacuzzi: false,
    hasFireplace: true,
    hasPrivatePool: false,
    isPopular: true,
    rating: 4.9,
    reviewCount: 127,
  },
  {
    id: '2',
    name: 'Göl Manzaralı Suite',
    slug: 'gol-manzarali-suite',
    description: 'Göl kenarında konumlanan lüks suite bungalovumuz, jakuzi ve özel iskelesiye eşsiz bir tatil deneyimi sunuyor. Gün batımında göl manzarası eşliğinde romantik anlar yaşayın.',
    shortDescription: 'Jakuzili göl kenarı lüks deneyimi',
    capacity: 2,
    bedrooms: 1,
    bathrooms: 1,
    size: 50,
    pricePerNight: 3500,
    images: [
      'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&auto=format&fit=crop',
    ],
    features: ['Göl Manzarası', 'Özel Jakuzi', 'Özel İskele', 'Romantik Dekor'],
    amenities: ['WiFi', 'Klima', 'Mini Bar', 'Espresso Makinesi', 'Bornoz & Terlik', 'Smart TV'],
    view: 'göl',
    hasJacuzzi: true,
    hasFireplace: false,
    hasPrivatePool: false,
    isPopular: true,
    rating: 4.95,
    reviewCount: 89,
  },
  {
    id: '3',
    name: 'Dağ Evi Premium',
    slug: 'dag-evi-premium',
    description: 'Yüksek rakımda, karlı dağ manzarasına bakan premium bungalov. Kış aylarında şömine başında sıcak bir ortam, yaz aylarında serin bir kaçamak. Aileniz için ideal seçim.',
    shortDescription: 'Aileler için dağ manzaralı geniş bungalov',
    capacity: 6,
    bedrooms: 3,
    bathrooms: 2,
    size: 95,
    pricePerNight: 4500,
    images: [
      'https://images.unsplash.com/photo-1518732714860-b62714ce0c59?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1595521624992-48a59aef95e3?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?w=800&auto=format&fit=crop',
    ],
    features: ['Dağ Manzarası', 'Geniş Teras', 'Şömine', 'Barbekü Alanı', 'Çocuk Oyun Alanı'],
    amenities: ['WiFi', 'Merkezi Isıtma', 'Tam Donanımlı Mutfak', 'Çamaşır Makinesi', 'Otopark', 'Bebek Yatağı'],
    view: 'dağ',
    hasJacuzzi: false,
    hasFireplace: true,
    hasPrivatePool: false,
    isPopular: false,
    rating: 4.85,
    reviewCount: 64,
  },
  {
    id: '4',
    name: 'Lüks Villa Bungalov',
    slug: 'luks-villa-bungalov',
    description: 'En üst düzey konfor ve lüksü bir arada sunan villa konseptinde bungalov. Özel havuz, jakuzi ve geniş yaşam alanları ile VIP tatil deneyimi.',
    shortDescription: 'Özel havuzlu ultra lüks villa deneyimi',
    capacity: 8,
    bedrooms: 4,
    bathrooms: 3,
    size: 150,
    pricePerNight: 7500,
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop',
    ],
    features: ['Özel Havuz', 'Jakuzi', 'Panoramik Manzara', 'Sinema Odası', 'Fitness Alanı'],
    amenities: ['Fiber İnternet', 'Akıllı Ev Sistemi', 'Şef Mutfağı', 'Kurutma Makinesi', 'Garaj', 'Concierge'],
    view: 'orman',
    hasJacuzzi: true,
    hasFireplace: true,
    hasPrivatePool: true,
    isPopular: true,
    rating: 5.0,
    reviewCount: 42,
  },
  {
    id: '5',
    name: 'Romantik Kabin',
    slug: 'romantik-kabin',
    description: 'Çiftler için tasarlanmış samimi ve romantik ahşap kabin. Doğa ile iç içe, huzurlu bir ortamda baş başa vakit geçirin.',
    shortDescription: 'Çiftler için romantik doğa kaçamağı',
    capacity: 2,
    bedrooms: 1,
    bathrooms: 1,
    size: 35,
    pricePerNight: 1800,
    images: [
      'https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800&auto=format&fit=crop',
    ],
    features: ['Şömine', 'Özel Balkon', 'Yıldız Gözlem Terasesi', 'Jakuzi'],
    amenities: ['WiFi', 'Bluetooth Hoparlör', 'Şarap Soğutucu', 'Premium Yatak Takımı', 'Aromatik Set'],
    view: 'orman',
    hasJacuzzi: true,
    hasFireplace: true,
    hasPrivatePool: false,
    isPopular: false,
    rating: 4.92,
    reviewCount: 156,
  },
  {
    id: '6',
    name: 'Deniz Esintisi',
    slug: 'deniz-esintisi',
    description: 'Denize sıfır konumuyla dalga seslerini duyabileceğiniz özel bungalov. Sabah kahvenizi deniz manzarası eşliğinde için.',
    shortDescription: 'Denize sıfır huzurlu bungalov',
    capacity: 4,
    bedrooms: 2,
    bathrooms: 1,
    size: 55,
    pricePerNight: 3200,
    images: [
      'https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&auto=format&fit=crop',
    ],
    features: ['Deniz Manzarası', 'Özel Plaj Girişi', 'Geniş Veranda', 'Hamak'],
    amenities: ['WiFi', 'Klima', 'Plaj Ekipmanları', 'Açık Duş', 'BBQ', 'Bisiklet'],
    view: 'deniz',
    hasJacuzzi: false,
    hasFireplace: false,
    hasPrivatePool: false,
    isPopular: true,
    rating: 4.88,
    reviewCount: 203,
  },
];

export const getBungalowBySlug = (slug: string): Bungalow | undefined => {
  return bungalows.find(b => b.slug === slug);
};

export const getPopularBungalows = (): Bungalow[] => {
  return bungalows.filter(b => b.isPopular);
};

export const filterBungalows = (filters: {
  capacity?: number;
  view?: string;
  hasJacuzzi?: boolean;
  minPrice?: number;
  maxPrice?: number;
}): Bungalow[] => {
  return bungalows.filter(b => {
    if (filters.capacity && b.capacity < filters.capacity) return false;
    if (filters.view && b.view !== filters.view) return false;
    if (filters.hasJacuzzi && !b.hasJacuzzi) return false;
    if (filters.minPrice && b.pricePerNight < filters.minPrice) return false;
    if (filters.maxPrice && b.pricePerNight > filters.maxPrice) return false;
    return true;
  });
};
